-- | Pure helpers that apply `NodeChange` and `EdgeChange` values to
-- | arrays of nodes and edges. Ports
-- | `xyflow/packages/react/src/utils/changes.ts` 1:1, with TS
-- | mutable-update style replaced by record-update returning new values.
-- |
-- | All functions are pure — the React reducer calls them inline and
-- | tests them directly with QuickCheck.
module React.Store.Changes
  ( applyNodeChanges
  , applyEdgeChanges
  , createSelectionChangePayload
  , getNodeSelectionChanges
  , getEdgeSelectionChanges
  , getNodeElementsDiffChanges
  , getEdgeElementsDiffChanges
  , nodeToRemoveChange
  , edgeToRemoveChange
  , SelectionChangePayload
  ) where

import Prelude

import Data.Array (insertAt, length, snoc, uncons) as Array
import Data.Foldable (foldl)
import Data.Map (Map)
import Data.Map as Map
import Data.Maybe (Maybe(..), fromMaybe)
import Data.Set (Set)
import Data.Set as Set
import Data.Tuple (Tuple(..))
import React.Types.Edges (Edge)
import React.Types.Nodes (Node)
import System.Types.Edge (EdgeChange(..), EdgeLookup)
import System.Types.Ids (NodeId)
import Unsafe.Reference (unsafeRefEq)
import System.Types.Node
  ( InternalNodeBase
  , NodeChange(..)
  , NodeLookup
  )

-- | Selection-change payload independent of node-vs-edge. The wrappers
-- | below promote it into a `NodeChange n` or `EdgeChange e`.
type SelectionChangePayload = { id :: String, selected :: Boolean }

createSelectionChangePayload :: String -> Boolean -> SelectionChangePayload
createSelectionChangePayload id selected = { id, selected }

-- | One bucket per change kind. `remove`/`replace` for an id wipes the
-- | per-id list (subsequent normal changes are pointless); `add` goes to
-- | its own bucket because adds happen *after* the existing-elements
-- | walk so indexed inserts land correctly.
type NodeChangeBuckets n =
  { byId :: Map NodeId (Array (NodeChange n))
  , adds :: Array (NodeChange n)
  }

type EdgeChangeBuckets e =
  { byId :: Map String (Array (EdgeChange e))
  , adds :: Array (EdgeChange e)
  }

partitionNodeChanges :: forall n. Array (NodeChange n) -> NodeChangeBuckets n
partitionNodeChanges = foldl step { byId: Map.empty, adds: [] }
  where
  step acc c = case c of
    NodeAddChange _ -> acc { adds = Array.snoc acc.adds c }
    NodeRemoveChange { id } -> acc { byId = Map.insert id [ c ] acc.byId }
    NodeReplaceChange { id } -> acc { byId = Map.insert id [ c ] acc.byId }
    NodeDimensionChange { id } -> acc { byId = appendChange id c acc.byId }
    NodePositionChange { id } -> acc { byId = appendChange id c acc.byId }
    NodeSelectionChange { id } -> acc { byId = appendChange id c acc.byId }

  appendChange id c m = case Map.lookup id m of
    Nothing -> Map.insert id [ c ] m
    Just existing -> Map.insert id (Array.snoc existing c) m

partitionEdgeChanges :: forall e. Array (EdgeChange e) -> EdgeChangeBuckets e
partitionEdgeChanges = foldl step { byId: Map.empty, adds: [] }
  where
  step acc c = case c of
    EdgeAddChange _ -> acc { adds = Array.snoc acc.adds c }
    EdgeRemoveChange { id } -> acc { byId = Map.insert id [ c ] acc.byId }
    EdgeReplaceChange { id } -> acc { byId = Map.insert id [ c ] acc.byId }
    EdgeSelectionChange { id } -> acc { byId = appendChange id c acc.byId }

  appendChange id c m = case Map.lookup id m of
    Nothing -> Map.insert id [ c ] m
    Just existing -> Map.insert id (Array.snoc existing c) m

-- | Apply a single non-terminal change to a node. The outer driver
-- | handles `Remove` / `Replace` / `Add`.
applySingleNodeChange :: forall n. NodeChange n -> Node n -> Node n
applySingleNodeChange c node = case c of
  NodeSelectionChange { selected } -> node { selected = Just selected }
  NodePositionChange { position, dragging } ->
    let
      withPos = case position of
        Just p -> node { position = p }
        Nothing -> node
    in
      -- TS `if (typeof change.dragging !== 'undefined')`.
      case dragging of
        Just _ -> withPos { dragging = dragging }
        Nothing -> withPos
  NodeDimensionChange { dimensions, setAttributes, resizing } ->
    let
      measured = case dimensions of
        Nothing -> node
        Just d ->
          let
            withMeasured =
              node { measured = { width: Just d.width, height: Just d.height } }
          in
            case setAttributes of
              Nothing -> withMeasured
              Just sa ->
                let
                  n1 = if sa.width then withMeasured { width = Just d.width } else withMeasured
                  n2 = if sa.height then n1 { height = Just d.height } else n1
                in
                  n2
    in case resizing of
      Nothing -> measured
      Just _ -> measured { resizing = resizing }
  -- Remove / Replace / Add are routed in the outer driver.
  NodeRemoveChange _ -> node
  NodeReplaceChange _ -> node
  NodeAddChange _ -> node

applySingleEdgeChange :: forall e. EdgeChange e -> Edge e -> Edge e
applySingleEdgeChange c edge = case c of
  EdgeSelectionChange { selected } -> edge { selected = Just selected }
  _ -> edge

-- | Apply all queued changes for one node id. Returns `Nothing` if the
-- | element should be dropped (remove change present).
-- |
-- | TS inspects `changes[0]` alone for `remove` and `replace` and then
-- | `continue`s the element loop, so anything queued *behind* either one is
-- | dropped — a replace hands over a whole new element, and a partial update
-- | computed against the old one has nothing left to say. Both can only ever
-- | be the head: bucketing a remove or a replace overwrites the id's list
-- | rather than appending to it.
applyChangesForNode
  :: forall n. Node n -> Array (NodeChange n) -> Maybe (Node n)
applyChangesForNode node changes = case Array.uncons changes of
  Nothing -> Just node
  Just { head } -> case head of
    NodeRemoveChange _ -> Nothing
    NodeReplaceChange { item } -> Just item
    _ -> Just (foldl (\curr c -> applySingleNodeChange c curr) node changes)

applyChangesForEdge
  :: forall e. Edge e -> Array (EdgeChange e) -> Maybe (Edge e)
applyChangesForEdge edge changes = case Array.uncons changes of
  Nothing -> Just edge
  Just { head } -> case head of
    EdgeRemoveChange _ -> Nothing
    EdgeReplaceChange { item } -> Just item
    _ -> Just (foldl (\curr c -> applySingleEdgeChange c curr) edge changes)

-- | Public: apply an array of `NodeChange`s to an array of nodes.
applyNodeChanges
  :: forall n. Array (NodeChange n) -> Array (Node n) -> Array (Node n)
applyNodeChanges changes nodes =
  let
    buckets = partitionNodeChanges changes
    afterUpdates =
      foldl
        ( \acc node -> case Map.lookup node.id buckets.byId of
            Nothing -> Array.snoc acc node
            Just cs -> case applyChangesForNode node cs of
              Nothing -> acc
              Just updated -> Array.snoc acc updated
        )
        []
        nodes
  in
    foldl applyNodeAdd afterUpdates buckets.adds
  where
  applyNodeAdd acc c = case c of
    NodeAddChange { item, index } -> insertItemAt index item acc
    _ -> acc

applyEdgeChanges
  :: forall e. Array (EdgeChange e) -> Array (Edge e) -> Array (Edge e)
applyEdgeChanges changes edges =
  let
    buckets = partitionEdgeChanges changes
    afterUpdates =
      foldl
        ( \acc edge -> case Map.lookup edge.id buckets.byId of
            Nothing -> Array.snoc acc edge
            Just cs -> case applyChangesForEdge edge cs of
              Nothing -> acc
              Just updated -> Array.snoc acc updated
        )
        []
        edges
  in
    foldl applyEdgeAdd afterUpdates buckets.adds
  where
  applyEdgeAdd acc c = case c of
    EdgeAddChange { item, index } -> insertItemAt index item acc
    _ -> acc

-- | Place an `add` change's item. TS runs the adds after the existing-elements
-- | walk so an index lands against the final array, then
-- | `updatedElements.splice(change.index, 0, item)` — and `splice` *clamps*
-- | its start rather than refusing: past the end appends, and a negative
-- | counts back from the end, bottoming out at 0. `Array.insertAt` rejects
-- | both, so the clamp is spelled out here.
insertItemAt :: forall a. Maybe Int -> a -> Array a -> Array a
insertItemAt mIndex item arr = case mIndex of
  Nothing -> Array.snoc arr item
  Just i ->
    let
      len = Array.length arr
      at = if i < 0 then max 0 (len + i) else min i len
    in
      fromMaybe (Array.snoc arr item) (Array.insertAt at item arr)

-- | Selection-diff helper. Polymorphic in the key type so it works
-- | for both `NodeLookup` (keyed by `NodeId`) and `EdgeLookup`
-- | (keyed by `String`), and in how the item holds `selected`: a node's is a
-- | `Boolean`, and an edge's is a `Maybe Boolean`, read as `false` when it's
-- | unset. That reading is upstream's
-- | `!(item.selected === undefined && !willBeSelected) && item.selected !== willBeSelected`.
getSelectionChangesGeneric
  :: forall k s r
   . Ord k
  => (s -> Boolean)
  -> (Boolean -> s)
  -> Map k { id :: k, selected :: s | r }
  -> Set k
  -> Boolean
  -> { changes :: Array { id :: k, selected :: Boolean }
     , items :: Map k { id :: k, selected :: s | r }
     }
getSelectionChangesGeneric isSelected toSelected items selectedIds mutate =
  let
    pairs :: Array (Tuple k { id :: k, selected :: s | r })
    pairs = Map.toUnfoldable items
    step acc (Tuple id item) =
      let
        willBeSelected = Set.member id selectedIds
      in
        if isSelected item.selected /= willBeSelected then
          let
            change = { id: item.id, selected: willBeSelected }
            newItems =
              if mutate then
                Map.insert id (item { selected = toSelected willBeSelected }) acc.items
              else acc.items
          in
            acc { changes = Array.snoc acc.changes change, items = newItems }
        else acc
  in
    foldl step { changes: [], items } pairs

getNodeSelectionChanges
  :: forall n
   . NodeLookup n
  -> Set NodeId
  -> Boolean
  -> { changes :: Array (NodeChange n)
     , items :: NodeLookup n
     }
getNodeSelectionChanges lookup selectedIds mutate =
  let
    r = getSelectionChangesGeneric (_ == Just true) Just lookup selectedIds mutate
    changes = map (\p -> NodeSelectionChange { id: p.id, selected: p.selected }) r.changes
  in
    { changes, items: r.items }

getEdgeSelectionChanges
  :: forall e
   . EdgeLookup e
  -> Set String
  -> { changes :: Array (EdgeChange e)
     }
getEdgeSelectionChanges lookup selectedIds =
  let
    r = getSelectionChangesGeneric (_ == Just true) Just lookup selectedIds false
    changes = map (\p -> EdgeSelectionChange { id: p.id, selected: p.selected }) r.changes
  in
    { changes }

-- | Diff between a fresh user-supplied node array and the store's
-- | current lookup. Produces `add` / `remove` / `replace` changes.
-- |
-- | TS replaces an item only when it isn't the object the store holds:
-- | `storeItem !== item`, where `storeItem` is the lookup's
-- | `internals.userNode`. ps-flow's internal node doesn't keep the user
-- | node, so the comparison is against the node with the same id in
-- | `currentNodes`, the array the lookup was adopted from.
getNodeElementsDiffChanges
  :: forall n
   . Maybe (Array (Node n))
  -> NodeLookup n
  -> Array (Node n)
  -> Array (NodeChange n)
getNodeElementsDiffChanges mItems lookup currentNodes =
  let
    items = case mItems of
      Just xs -> xs
      Nothing -> []
    itemsLookup :: Map NodeId (Node n)
    itemsLookup = Map.fromFoldable (map (\n -> Tuple n.id n) items)
    userNodes :: Map NodeId (Node n)
    userNodes = Map.fromFoldable (map (\n -> Tuple n.id n) currentNodes)
    forwardPass = foldl forwardStep { changes: [], index: 0 } items
    forwardStep acc item =
      let
        change
          | Map.member item.id lookup = case Map.lookup item.id userNodes of
              Just stored | unsafeRefEq stored item -> []
              _ -> [ NodeReplaceChange { id: item.id, item } ]
          | otherwise = [ NodeAddChange { item, index: Just acc.index } ]
      in
        { changes: acc.changes <> change, index: acc.index + 1 }
    removes =
      foldl
        ( \acc (Tuple id _) ->
            if Map.member id itemsLookup then acc
            else Array.snoc acc (NodeRemoveChange { id })
        )
        []
        (Map.toUnfoldable lookup :: Array (Tuple NodeId (InternalNodeBase n)))
  in
    forwardPass.changes <> removes

getEdgeElementsDiffChanges
  :: forall e
   . Maybe (Array (Edge e))
  -> EdgeLookup e
  -> Array (EdgeChange e)
getEdgeElementsDiffChanges mItems lookup =
  let
    items = case mItems of
      Just xs -> xs
      Nothing -> []
    itemsLookup :: Map String (Edge e)
    itemsLookup = Map.fromFoldable (map (\e -> Tuple e.id e) items)
    forwardPass = foldl forwardStep { changes: [], index: 0 } items
    -- TS replaces an item only when it isn't the object the lookup holds.
    forwardStep acc item =
      let
        change = case Map.lookup item.id lookup of
          Just stored
            | unsafeRefEq stored item -> []
            | otherwise -> [ EdgeReplaceChange { id: item.id, item } ]
          Nothing -> [ EdgeAddChange { item, index: Just acc.index } ]
      in
        { changes: acc.changes <> change, index: acc.index + 1 }
    removes =
      foldl
        ( \acc (Tuple id _) ->
            if Map.member id itemsLookup then acc
            else Array.snoc acc (EdgeRemoveChange { id })
        )
        []
        (Map.toUnfoldable lookup :: Array (Tuple String (Edge e)))
  in
    forwardPass.changes <> removes

nodeToRemoveChange :: forall n. Node n -> NodeChange n
nodeToRemoveChange n = NodeRemoveChange { id: n.id }

edgeToRemoveChange :: forall e. Edge e -> EdgeChange e
edgeToRemoveChange e = EdgeRemoveChange { id: e.id }
