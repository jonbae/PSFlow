-- | Store reconciliation utilities. Mirrors `utils/store.ts`.
-- |
-- | The four reconciliation functions — `adoptUserNodes`,
-- | `updateAbsolutePositions`, `updateConnectionLookup`,
-- | `handleExpandParent` — are pure (value-in / value-out). The React
-- | reducer (ticket 026) calls them directly; the `Ref` shell that the TS
-- | source uses to mutate `Map`s in place lives outside this module.
-- |
-- | The remaining two functions are effectful by necessity:
-- | `updateNodeInternals` is `Effect` because it reads the DOM
-- | (`getDimensions`, `elementBoundingRect`, `getHandleBounds`,
-- | `findViewportZoom`); `panBy` is `Aff` because viewport setters are
-- | async.
module System.Utils.Store
  ( UpdateNodesOptions
  , defaultUpdateNodesOptions
  , AdoptUserNodesReturn
  , isManualZIndexMode
  , updateAbsolutePositions
  , adoptUserNodes
  , handleExpandParent
  , updateNodeInternals
  , setUpdate
  , updateConnectionLookup
  , insertHandleConnection
  , handleConnectionsInOrder
  , panBy
  , selectedNodeZ
  , rootParentZIncrement
  ) where

import Prelude

import Data.Array (any, findIndex, foldl, fromFoldable, length, mapMaybe, reverse, snoc, updateAt) as Array
import Data.List (List(..), (:))
import Data.Either (Either(..))
import Data.Foldable (foldM, foldl) as Foldable
import Data.Int (toNumber) as Int
import Data.Map (Map)
import Data.Map (empty, insert, lookup, member, toUnfoldable, values) as Map
import Data.Maybe (Maybe(..), fromMaybe, isJust, isNothing)
import Data.Newtype (unwrap)
import Data.Number (abs, round) as Number
import Data.Tuple (Tuple(..))
import Effect (Effect)
import Effect.Aff (Aff)
import Web.HTML.HTMLElement (HTMLElement)
import System.Constants (infiniteExtent)
import System.FFI.D3Zoom (zoomTransformK, zoomTransformX, zoomTransformY)
import System.Types.Connection
  ( ConnectionLookup
  , HandleConnection
  , HandleConnections
  , ZIndexMode(..)
  )
import System.Types.Edge (EdgeBase, EdgeLookup)
import System.Types.Geometry
  ( CoordinateExtent(..)
  , NodeOrigin(..)
  , Rect
  , Transform(..)
  , XYPosition
  , mkNodeOrigin
  )
import System.Types.Handle (Handle, HandleType(..), SourceHandle(..), TargetHandle(..), mkSourceHandle, mkTargetHandle)
import System.Types.Ids (ParentId, parentToNode, nodeToParent)
import System.Types.Node
  ( InternalNodeBase
  , InternalNodeUpdate
  , NodeBase
  , NodeChange(..)
  , NodeExtent(..)
  , NodeHandleBounds
  , NodeLookup
  , ParentExpandChild
  , ParentLookup
  , userNodeIdentity
  )
import System.Types.PanZoom (PanZoomInstance)
import Unsafe.Reference (unsafeRefEq)
import System.Utils.Dom
  ( elementBoundingRect
  , findViewportZoom
  , getDimensions
  , getHandleBounds
  )
import System.Utils.General
  ( clampPosition
  , clampPositionToParent
  , getBoundsOfRects
  , getNodeDimensions
  , getNodePositionWithOrigin
  , isCoordinateExtent
  , isNumeric
  , nodeToRect
  )

-- | Magic numbers from the TS source.
selectedNodeZ :: Int
selectedNodeZ = 1000

rootParentZIncrement :: Int
rootParentZIncrement = 10

type UpdateNodesOptions n =
  { nodeOrigin :: NodeOrigin
  , nodeExtent :: CoordinateExtent
  , elevateNodesOnSelect :: Boolean
  , defaults :: Maybe (NodeBase n -> NodeBase n)
  , zIndexMode :: ZIndexMode
  , checkEquality :: Boolean
  }

defaultUpdateNodesOptions :: forall n. UpdateNodesOptions n
defaultUpdateNodesOptions =
  { nodeOrigin: mkNodeOrigin 0.0 0.0
  , nodeExtent: infiniteExtent
  , elevateNodesOnSelect: true
  , defaults: Nothing
  , zIndexMode: ZBasic
  , checkEquality: true
  }

type AdoptUserNodesReturn =
  { nodesInitialized :: Boolean
  , hasSelectedNodes :: Boolean
  }

isManualZIndexMode :: ZIndexMode -> Boolean
isManualZIndexMode = case _ of
  ZManual -> true
  _ -> false

-- Pure helpers --------------------------------------------------------------

-- | Row-polymorphic so it accepts both NodeBase and InternalNodeBase
-- | without going through `toBaseLike` (which is gone — see ticket 021 #1).
calculateZ
  :: forall r
   . { zIndex :: Maybe Int, selected :: Maybe Boolean | r }
  -> Int
  -> ZIndexMode
  -> Number
calculateZ node selZ zMode =
  let
    zIndex = case node.zIndex of
      Just z | isNumeric (Int.toNumber z) -> Int.toNumber z
      _ -> 0.0
    bonus =
      if isManualZIndexMode zMode then 0.0
      else if node.selected == Just true then Int.toNumber selZ
      else 0.0
  in
    zIndex + bonus

calculateChildXYZ
  :: forall n
   . InternalNodeBase n
  -> InternalNodeBase n
  -> NodeOrigin
  -> CoordinateExtent
  -> Int
  -> ZIndexMode
  -> { x :: Number, y :: Number, z :: Number }
calculateChildXYZ child parent origin extent selZ zMode =
  let
    parentX = parent.internals.positionAbsolute.x
    parentY = parent.internals.positionAbsolute.y
    -- Ticket 021 #8: getNodeDimensions returns Maybe Dimensions. When the
    -- child is unmeasured we treat its size as 0×0 for clamping purposes,
    -- matching the previous (pre-Maybe) behaviour at this call site.
    childDimensions = fromMaybe { width: 0.0, height: 0.0 }
      (getNodeDimensions child)
    positionWithOrigin = getNodePositionWithOrigin child origin
    childExtent = isCoordinateExtent child.extent
    clampedRel = case childExtent of
      Just ce -> clampPosition positionWithOrigin ce
        { width: Just childDimensions.width
        , height: Just childDimensions.height
        }
      Nothing -> positionWithOrigin
    absInitial =
      clampPosition
        { x: parentX + clampedRel.x, y: parentY + clampedRel.y }
        extent
        { width: Just childDimensions.width
        , height: Just childDimensions.height
        }
    absoluteFinal = case child.extent of
      Just ParentExtent ->
        clampPositionToParent absInitial childDimensions parent
      _ -> absInitial
    childZ = calculateZ child selZ zMode
    parentZ = parent.internals.z
  in
    { x: absoluteFinal.x
    , y: absoluteFinal.y
    , z: if parentZ >= childZ then parentZ + 1.0 else childZ
    }

updateParentLookup
  :: forall n. InternalNodeBase n -> ParentLookup n -> ParentLookup n
updateParentLookup node parentLookup = case node.parentId of
  Nothing -> parentLookup
  Just pid ->
    let
      childMap = case Map.lookup pid parentLookup of
        Just m -> m
        Nothing -> Map.empty
    in
      Map.insert pid (Map.insert node.id node childMap) parentLookup

updateChildNodePure
  :: forall n
   . InternalNodeBase n
  -> NodeLookup n
  -> ParentLookup n
  -> UpdateNodesOptions n
  -> Maybe Int
  -> { node :: InternalNodeBase n
     , nodeLookup :: NodeLookup n
     , parentLookup :: ParentLookup n
     , rootParentIndex :: Maybe Int
     }
updateChildNodePure node nodeLookup parentLookup options rootParentIndex =
  case node.parentId of
    Nothing -> { node, nodeLookup, parentLookup, rootParentIndex }
    Just parentId ->
      case Map.lookup (parentToNode parentId) nodeLookup of
        Nothing -> { node, nodeLookup, parentLookup, rootParentIndex }
        Just parentNode ->
          let
            parentLookup1 = updateParentLookup node parentLookup

            shouldBump = case rootParentIndex, parentNode.parentId of
              Just _, Nothing ->
                parentNode.internals.rootParentIndex == Nothing
                  && options.zIndexMode == ZAuto
              _, _ -> false

            { parentNode2, nextRootIndex } =
              if shouldBump then
                let
                  nextI = (fromMaybe 0 rootParentIndex) + 1
                  bumped = parentNode
                    { internals = parentNode.internals
                        { rootParentIndex = Just nextI
                        , z = parentNode.internals.z
                            + Int.toNumber nextI * Int.toNumber rootParentZIncrement
                        }
                    }
                in
                  { parentNode2: bumped, nextRootIndex: Just nextI }
              else
                let
                  next = case rootParentIndex, parentNode.internals.rootParentIndex of
                    Just _, Just i -> Just i
                    _, _ -> rootParentIndex
                in
                  { parentNode2: parentNode, nextRootIndex: next }

            nodeLookupAfterParent =
              Map.insert parentNode2.id parentNode2 nodeLookup

            selZ =
              if options.elevateNodesOnSelect
                && not (isManualZIndexMode options.zIndexMode) then selectedNodeZ
              else 0

            xyz = calculateChildXYZ node parentNode2 options.nodeOrigin
              options.nodeExtent
              selZ
              options.zIndexMode

            positionAbs = node.internals.positionAbsolute
            positionChanged = xyz.x /= positionAbs.x || xyz.y /= positionAbs.y

            updatedNode =
              if positionChanged || xyz.z /= node.internals.z then
                node
                  { internals = node.internals
                      { positionAbsolute =
                          if positionChanged then { x: xyz.x, y: xyz.y }
                          else positionAbs
                      , z = xyz.z
                      }
                  }
              else node

            nodeLookupFinal =
              Map.insert node.id updatedNode nodeLookupAfterParent
          in
            { node: updatedNode
            , nodeLookup: nodeLookupFinal
            , parentLookup: parentLookup1
            , rootParentIndex: nextRootIndex
            }

-- Public reconciliation functions (pure) -----------------------------------

updateAbsolutePositions
  :: forall n
   . NodeLookup n
  -> ParentLookup n
  -> UpdateNodesOptions n
  -> { nodeLookup :: NodeLookup n, parentLookup :: ParentLookup n }
updateAbsolutePositions initial parents options =
  let
    finalState = Foldable.foldl
      ( \st node ->
          if isJust node.parentId then
            let
              r = updateChildNodePure node st.nodeLookup st.parentLookup
                options
                st.rootParentIndex
            in
              { nodeLookup: r.nodeLookup
              , parentLookup: r.parentLookup
              , rootParentIndex: r.rootParentIndex
              }
          else
            let
              positionWithOrigin =
                getNodePositionWithOrigin node options.nodeOrigin
              ext = case isCoordinateExtent node.extent of
                Just ce -> ce
                Nothing -> options.nodeExtent
              dims = fromMaybe { width: 0.0, height: 0.0 }
                (getNodeDimensions node)
              clamped = clampPosition positionWithOrigin ext
                { width: Just dims.width, height: Just dims.height }
              updated = node
                { internals = node.internals
                    { positionAbsolute = clamped }
                }
            in
              st { nodeLookup = Map.insert node.id updated st.nodeLookup }
      )
      { nodeLookup: initial
      , parentLookup: parents
      , rootParentIndex: Nothing :: Maybe Int
      }
      (Map.values initial)
  in
    { nodeLookup: finalState.nodeLookup
    , parentLookup: finalState.parentLookup
    }

adoptUserNodes
  :: forall n
   . Array (NodeBase n)
  -> NodeLookup n
  -> ParentLookup n
  -> UpdateNodesOptions n
  -> { nodeLookup :: NodeLookup n
     , parentLookup :: ParentLookup n
     , nodesInitialized :: Boolean
     , hasSelectedNodes :: Boolean
     }
adoptUserNodes nodes prev _prevParent options =
  let
    selZ =
      if options.elevateNodesOnSelect
        && not (isManualZIndexMode options.zIndexMode) then selectedNodeZ
      else 0

    initial =
      { nodeLookup: (Map.empty :: NodeLookup n)
      , parentLookup: (Map.empty :: ParentLookup n)
      , nodesInitialized: Array.length nodes > 0
      , hasSelectedNodes: false
      , rootParentIndex: Just 0 :: Maybe Int
      }

    step st userNode =
      let
        userNodeWithDefaults = case options.defaults of
          Just f -> f userNode
          Nothing -> userNode
        positionWithOrigin =
          getNodePositionWithOrigin userNodeWithDefaults options.nodeOrigin
        extent = case isCoordinateExtent userNodeWithDefaults.extent of
          Just ce -> ce
          Nothing -> options.nodeExtent
        dims = fromMaybe { width: 0.0, height: 0.0 }
          (getNodeDimensions userNodeWithDefaults)
        clamped = clampPosition positionWithOrigin extent
          { width: Just dims.width, height: Just dims.height }
        oldInternal = Map.lookup userNodeWithDefaults.id prev
        internalNode :: InternalNodeBase n
        internalNode = case oldInternal of
          Just old | options.checkEquality
            && unsafeRefEq (userNodeIdentity userNode) (userNodeIdentity old.internals.userNode) -> old
          _ ->
              { id: userNodeWithDefaults.id
              , position: userNodeWithDefaults.position
              , data: userNodeWithDefaults.data
              , sourcePosition: userNodeWithDefaults.sourcePosition
              , targetPosition: userNodeWithDefaults.targetPosition
              , hidden: userNodeWithDefaults.hidden
              , selected: userNodeWithDefaults.selected
              , dragging: userNodeWithDefaults.dragging
              , draggable: userNodeWithDefaults.draggable
              , selectable: userNodeWithDefaults.selectable
              , connectable: userNodeWithDefaults.connectable
              , deletable: userNodeWithDefaults.deletable
              , dragHandle: userNodeWithDefaults.dragHandle
              , width: userNodeWithDefaults.width
              , height: userNodeWithDefaults.height
              , initialWidth: userNodeWithDefaults.initialWidth
              , initialHeight: userNodeWithDefaults.initialHeight
              , parentId: userNodeWithDefaults.parentId
              , zIndex: userNodeWithDefaults.zIndex
              , extent: userNodeWithDefaults.extent
              , expandParent: userNodeWithDefaults.expandParent
              , resizing: userNodeWithDefaults.resizing
              , ariaLabel: userNodeWithDefaults.ariaLabel
              , origin: userNodeWithDefaults.origin
              , handles: userNodeWithDefaults.handles
              , measured: userNodeWithDefaults.measured
              , nodeType: userNodeWithDefaults.nodeType
              , className: userNodeWithDefaults.className
              , style: userNodeWithDefaults.style
              , internals:
                  { positionAbsolute: clamped
                  , userNode
                  , z: calculateZ userNodeWithDefaults selZ options.zIndexMode
                  , rootParentIndex: case oldInternal of
                      Just o -> o.internals.rootParentIndex
                      Nothing -> Nothing
                  , handleBounds: parseHandles userNodeWithDefaults oldInternal
                  , bounds: case oldInternal of
                      Just o -> o.internals.bounds
                      Nothing -> Nothing
                  }
              }

        nodeLookup1 =
          Map.insert userNodeWithDefaults.id internalNode st.nodeLookup
        st1 = st { nodeLookup = nodeLookup1 }

        st2 =
          let
            measuredOk =
              isJust internalNode.measured.width
                && isJust internalNode.measured.height
          in
            if not measuredOk && internalNode.hidden /= Just true then
              st1 { nodesInitialized = false }
            else st1

        st3 = case userNodeWithDefaults.parentId of
          Just _ ->
            let
              r = updateChildNodePure internalNode st2.nodeLookup
                st2.parentLookup
                options
                st2.rootParentIndex
            in
              st2
                { nodeLookup = r.nodeLookup
                , parentLookup = r.parentLookup
                , rootParentIndex = r.rootParentIndex
                }
          Nothing -> st2
      in
        st3
          { hasSelectedNodes = st3.hasSelectedNodes || userNodeWithDefaults.selected == Just true
          }

    final = Foldable.foldl step initial nodes
  in
    { nodeLookup: final.nodeLookup
    , parentLookup: final.parentLookup
    , nodesInitialized: final.nodesInitialized
    , hasSelectedNodes: final.hasSelectedNodes
    }

parseHandles
  :: forall n
   . NodeBase n
  -> Maybe (InternalNodeBase n)
  -> Maybe NodeHandleBounds
parseHandles userNode internalNode = case userNode.handles of
  Nothing ->
    case userNode.measured.width, userNode.measured.height of
      Nothing, _ -> Nothing
      _, Nothing -> Nothing
      _, _ -> case internalNode of
        Just i -> i.internals.handleBounds
        Nothing -> Nothing
  Just handles ->
    let
      empty :: NodeHandleBounds
      empty = { source: [], target: [] }

      go acc h =
        let
          bounds :: Handle
          bounds =
            { id: h.id
            , width: fromMaybe 1.0 h.width
            , height: fromMaybe 1.0 h.height
            , nodeId: userNode.id
            , x: h.x
            , y: h.y
            , position: h.position
            , handleType: h.handleType
            }
        in
          -- The branch establishes `h.handleType`, so the data constructor
          -- is sound here without going through `mkSourceHandle`/`mkTargetHandle`.
          case h.handleType of
            Source -> acc { source = Array.snoc acc.source (SourceHandle bounds) }
            Target -> acc { target = Array.snoc acc.target (TargetHandle bounds) }
    in
      Just (Foldable.foldl go empty handles)

handleExpandParent
  :: forall n
   . Array ParentExpandChild
  -> NodeLookup n
  -> ParentLookup n
  -> NodeOrigin
  -> Array (NodeChange n)
handleExpandParent children nodeLookup parentLookup defaultOrigin =
  let
    expansions =
      Foldable.foldl
        ( \acc child ->
            case Map.lookup (parentToNode child.parentId) nodeLookup of
              Nothing -> acc
              Just parent ->
                let
                  prevRect = case Map.lookup child.parentId acc of
                    Just r -> r.expandedRect
                    Nothing -> nodeToRect (Right parent) defaultOrigin
                  expanded = getBoundsOfRects prevRect child.rect
                in
                  Map.insert child.parentId
                    { expandedRect: expanded, parent }
                    acc
        )
        ( Map.empty ::
            Map ParentId { expandedRect :: Rect, parent :: InternalNodeBase n }
        )
        children

    pairs :: Array (Tuple ParentId { expandedRect :: Rect, parent :: InternalNodeBase n })
    pairs = Map.toUnfoldable expansions
  in
    Array.foldl (stepExpansion children parentLookup defaultOrigin) [] pairs

stepExpansion
  :: forall n
   . Array ParentExpandChild
  -> ParentLookup n
  -> NodeOrigin
  -> Array (NodeChange n)
  -> Tuple ParentId { expandedRect :: Rect, parent :: InternalNodeBase n }
  -> Array (NodeChange n)
stepExpansion children parentLookup defaultOrigin changes (Tuple parentId rec) =
  let
    positionAbsolute = rec.parent.internals.positionAbsolute
    dimensions = fromMaybe { width: 0.0, height: 0.0 }
      (getNodeDimensions rec.parent)
    NodeOrigin origin = fromMaybe defaultOrigin rec.parent.origin

    xChange =
      if rec.expandedRect.x < positionAbsolute.x then
        Number.round (Number.abs (positionAbsolute.x - rec.expandedRect.x))
      else 0.0
    yChange =
      if rec.expandedRect.y < positionAbsolute.y then
        Number.round (Number.abs (positionAbsolute.y - rec.expandedRect.y))
      else 0.0

    newWidth = max dimensions.width (Number.round rec.expandedRect.width)
    newHeight = max dimensions.height (Number.round rec.expandedRect.height)

    widthChange = (newWidth - dimensions.width) * origin.ox
    heightChange = (newHeight - dimensions.height) * origin.oy

    significantPositionChange =
      xChange > 0.0 || yChange > 0.0 || widthChange /= 0.0
        || heightChange /= 0.0

    posChange =
      if significantPositionChange then
        [ NodePositionChange
            { id: parentToNode parentId
            , position: Just
                { x: rec.parent.position.x - xChange + widthChange
                , y: rec.parent.position.y - yChange + heightChange
                }
            , positionAbsolute: Nothing
            , dragging: Nothing
            }
        ]
      else []

    childPosChanges =
      if significantPositionChange then
        case Map.lookup parentId parentLookup of
          Nothing -> []
          Just kids ->
            ( Array.fromFoldable (Map.values kids)
                # filterMap
                    ( \kid ->
                        if Array.any (\c -> c.id == kid.id) children then Nothing
                        else
                          Just
                            ( NodePositionChange
                                { id: kid.id
                                , position: Just
                                    { x: kid.position.x + xChange
                                    , y: kid.position.y + yChange
                                    }
                                , positionAbsolute: Nothing
                                , dragging: Nothing
                                }
                            )
                    )
            )
      else []

    significantDimensionChange =
      dimensions.width < rec.expandedRect.width
        || dimensions.height < rec.expandedRect.height
        || xChange /= 0.0
        || yChange /= 0.0

    dimChange =
      if significantDimensionChange then
        [ NodeDimensionChange
            { id: parentToNode parentId
            , dimensions: Just
                { width:
                    newWidth
                      +
                        ( if xChange /= 0.0 then origin.ox * xChange - widthChange
                          else 0.0
                        )
                , height:
                    newHeight
                      +
                        ( if yChange /= 0.0 then origin.oy * yChange - heightChange
                          else 0.0
                        )
                }
            , resizing: Nothing
            , setAttributes: Just { width: true, height: true }
            }
        ]
      else []
  in
    changes <> posChange <> childPosChanges <> dimChange

-- Local alias kept for the readable `# filterMap` pipeline above; uses the
-- standard library implementation (`Data.Array.mapMaybe`).
filterMap :: forall a b. (a -> Maybe b) -> Array a -> Array b
filterMap = Array.mapMaybe

-- DOM-driven node-internals update -----------------------------------------

-- | `updates.set(update.id, update)` on upstream's `Map<string,
-- | InternalNodeUpdate>`: a new id goes last, and a repeated one keeps its
-- | place and takes the new value. `updateNodeInternals` walks the batch in
-- | that order, so its dimension changes list the nodes as the observer
-- | reported them, which on a first mount is the nodes' own order.
setUpdate :: InternalNodeUpdate -> Array InternalNodeUpdate -> Array InternalNodeUpdate
setUpdate update updates = case Array.findIndex (\u -> u.id == update.id) updates of
  Just i -> fromMaybe updates (Array.updateAt i update updates)
  Nothing -> Array.snoc updates update

updateNodeInternals
  :: forall n
   . Array InternalNodeUpdate
  -> NodeLookup n
  -> ParentLookup n
  -> Maybe HTMLElement
  -> NodeOrigin
  -> CoordinateExtent
  -> ZIndexMode
  -> Effect
       { nodeLookup :: NodeLookup n
       , parentLookup :: ParentLookup n
       , changes :: Array (NodeChange n)
       , updatedInternals :: Boolean
       }
updateNodeInternals updates nodeLookup0 parentLookup0 mDom origin extent zMode =
  case mDom of
    Nothing -> pure
      { nodeLookup: nodeLookup0
      , parentLookup: parentLookup0
      , changes: []
      , updatedInternals: false
      }
    Just dom -> do
      mZoom <- findViewportZoom dom
      case mZoom of
        Nothing -> pure
          { nodeLookup: nodeLookup0
          , parentLookup: parentLookup0
          , changes: []
          , updatedInternals: false
          }
        Just zoom -> do
          let
            initial =
              { nodeLookup: nodeLookup0
              , parentLookup: parentLookup0
              , changes: ([] :: Array (NodeChange n))
              , parentExpandChildren: ([] :: Array ParentExpandChild)
              , updatedInternals: false
              }
          result <-
            Foldable.foldM
              ( \acc u -> processUpdate u acc zoom origin extent zMode )
              initial
              updates
          let
            finalChanges =
              if Array.length result.parentExpandChildren > 0 then
                result.changes
                  <> handleExpandParent result.parentExpandChildren
                    result.nodeLookup
                    result.parentLookup
                    origin
              else result.changes
          pure
            { nodeLookup: result.nodeLookup
            , parentLookup: result.parentLookup
            , changes: finalChanges
            , updatedInternals: result.updatedInternals
            }

type UpdateAcc n =
  { nodeLookup :: NodeLookup n
  , parentLookup :: ParentLookup n
  , changes :: Array (NodeChange n)
  , parentExpandChildren :: Array ParentExpandChild
  , updatedInternals :: Boolean
  }

processUpdate
  :: forall n
   . InternalNodeUpdate
  -> UpdateAcc n
  -> Number
  -> NodeOrigin
  -> CoordinateExtent
  -> ZIndexMode
  -> Effect (UpdateAcc n)
processUpdate update acc zoom origin extent zMode =
  case Map.lookup update.id acc.nodeLookup of
    Nothing -> pure acc
    Just node ->
      if node.hidden == Just true then
        let
          cleared = node
            { internals = node.internals { handleBounds = Nothing } }
        in
          pure
            ( acc
                { nodeLookup =
                    Map.insert node.id cleared acc.nodeLookup
                , updatedInternals = true
                }
            )
      else do
        dims <- getDimensions update.nodeElement
        let
          dimensionChanged =
            node.measured.width /= Just dims.width
              || node.measured.height /= Just dims.height
          shouldUpdate =
            dims.width > 0.0 && dims.height > 0.0
              &&
                ( dimensionChanged
                    || isNothing node.internals.handleBounds
                    || update.force
                )
        if not shouldUpdate then pure acc
        else do
          nodeBounds <- elementBoundingRect update.nodeElement
          let
            chosenExt = case isCoordinateExtent node.extent of
              Just ce -> Just ce
              Nothing -> Just extent
            positionAbsoluteAdjusted = case node.parentId, node.extent of
              Just pid, Just ParentExtent ->
                case Map.lookup (parentToNode pid) acc.nodeLookup of
                  Just parent ->
                    clampPositionToParent node.internals.positionAbsolute dims
                      parent
                  Nothing -> node.internals.positionAbsolute
              _, _ -> case chosenExt of
                Just ce ->
                  clampPosition node.internals.positionAbsolute ce
                    { width: Just dims.width, height: Just dims.height }
                Nothing -> node.internals.positionAbsolute
          sourceHandles <- getHandleBounds Source update.nodeElement nodeBounds
            zoom
            node.id
          targetHandles <- getHandleBounds Target update.nodeElement nodeBounds
            zoom
            node.id
          let
            -- `getHandleBounds Source/Target` queries the DOM for handles
            -- of the requested side; the smart constructors enforce the
            -- invariant at the type-system boundary in case the DOM
            -- yields a handle of the other type.
            newNode = node
              { measured = { width: Just dims.width, height: Just dims.height }
              , internals = node.internals
                  { positionAbsolute = positionAbsoluteAdjusted
                  , handleBounds = Just
                      { source: Array.mapMaybe mkSourceHandle
                          (fromMaybe [] sourceHandles)
                      , target: Array.mapMaybe mkTargetHandle
                          (fromMaybe [] targetHandles)
                      }
                  }
              }
            nodeLookup1 = Map.insert node.id newNode acc.nodeLookup

            childResult = case node.parentId of
              Just _ ->
                let
                  r = updateChildNodePure newNode nodeLookup1 acc.parentLookup
                    ( defaultUpdateNodesOptions
                        { nodeOrigin = origin, zIndexMode = zMode }
                    )
                    Nothing
                in
                  { nodeLookup: r.nodeLookup, parentLookup: r.parentLookup }
              Nothing ->
                { nodeLookup: nodeLookup1, parentLookup: acc.parentLookup }

            -- TS pushes `{ id, type: 'dimensions', dimensions }`, with no
            -- `setAttributes`: a measurement sets the node's `measured` and
            -- leaves its own `width` and `height` as the consumer gave them.
            -- Only `handleExpandParent`'s change for a parent sets them.
            extraChanges =
              if dimensionChanged then
                [ NodeDimensionChange
                    { id: node.id
                    , dimensions: Just dims
                    , resizing: Nothing
                    , setAttributes: Nothing
                    }
                ]
              else []
            extraExpand = case node.parentId of
              Just pid | dimensionChanged && node.expandParent == Just true ->
                [ { id: node.id
                  , parentId: pid
                  , rect: nodeToRect (Right newNode) origin
                  }
                ]
              _ -> []
          pure
            ( acc
                { nodeLookup = childResult.nodeLookup
                , parentLookup = childResult.parentLookup
                , changes = acc.changes <> extraChanges
                , parentExpandChildren = acc.parentExpandChildren
                    <> extraExpand
                , updatedInternals = true
                }
            )

-- Connection lookup --------------------------------------------------------

addConnectionToLookup
  :: String
  -> HandleConnection
  -> String
  -> ConnectionLookup
  -> String
  -> Maybe String
  -> ConnectionLookup
addConnectionToLookup typeStr connection connectionKey connectionLookup nodeId mHandleId =
  let
    addAt key lookup =
      let
        inner = case Map.lookup key lookup of
          Just m -> m
          Nothing -> { byKey: Map.empty, order: Nil }
      in
        Map.insert key (insertHandleConnection connectionKey connection inner) lookup

    afterNode = addAt nodeId connectionLookup
    afterType = addAt (nodeId <> "-" <> typeStr) afterNode
  in
    case mHandleId of
      Just hid -> addAt (nodeId <> "-" <> typeStr <> "-" <> hid) afterType
      Nothing -> afterType

-- | Upstream's `nodeMap.set(connectionKey, connection)`. A key the map
-- | already holds keeps its position and takes the new connection.
insertHandleConnection :: String -> HandleConnection -> HandleConnections -> HandleConnections
insertHandleConnection key connection connections =
  { byKey: Map.insert key connection connections.byKey
  , order: if Map.member key connections.byKey then connections.order else key : connections.order
  }

-- | Upstream's `Array.from(connections.values())`: the connections in the
-- | order they were inserted.
handleConnectionsInOrder :: HandleConnections -> Array HandleConnection
handleConnectionsInOrder connections =
  Array.mapMaybe (\key -> Map.lookup key connections.byKey)
    (Array.reverse (Array.fromFoldable connections.order))

updateConnectionLookup
  :: forall e
   . Array (EdgeBase e)
  -> { connectionLookup :: ConnectionLookup, edgeLookup :: EdgeLookup e }
updateConnectionLookup edges =
  let
    initial =
      { connectionLookup: (Map.empty :: ConnectionLookup)
      , edgeLookup: (Map.empty :: EdgeLookup e)
      }
    final = Foldable.foldl
      ( \st edge ->
          let
            -- Connection composite keys are bare strings (internal
            -- index shape); the typed NodeIds are unwrapped at this
            -- boundary.
            sourceStr = unwrap edge.source
            targetStr = unwrap edge.target
            connection :: HandleConnection
            connection =
              { edgeId: edge.id
              , source: edge.source
              , target: edge.target
              , sourceHandle: edge.sourceHandle
              , targetHandle: edge.targetHandle
              }
            sourceKey =
              sourceStr <> "-" <> fromMaybe "null" edge.sourceHandle
                <> "--"
                <> targetStr
                <> "-"
                <> fromMaybe "null" edge.targetHandle
            targetKey =
              targetStr <> "-" <> fromMaybe "null" edge.targetHandle
                <> "--"
                <> sourceStr
                <> "-"
                <> fromMaybe "null" edge.sourceHandle
            connLookup1 =
              addConnectionToLookup "source" connection targetKey
                st.connectionLookup
                sourceStr
                edge.sourceHandle
            connLookup2 =
              addConnectionToLookup "target" connection sourceKey
                connLookup1
                targetStr
                edge.targetHandle
          in
            { connectionLookup: connLookup2
            , edgeLookup: Map.insert edge.id edge st.edgeLookup
            }
      )
      initial
      edges
  in
    { connectionLookup: final.connectionLookup
    , edgeLookup: final.edgeLookup
    }

-- Pan-by ------------------------------------------------------------------

-- | TS `panBy`. Constrain the requested viewport, apply it, and report
-- | whether it moved.
-- |
-- | The Boolean is what an auto-pan loop reads to decide whether to move the
-- | dragged nodes, so it has to distinguish "the viewport moved" from "d3
-- | gave us a transform". At a `translateExtent` boundary `constrain` returns
-- | the transform the viewport is already at, which is a refusal; a caller
-- | that reads a transform as success moves its nodes every frame while the
-- | viewport holds still. Upstream's `transformChanged` compares the
-- | constrained transform with the current one component by component, and
-- | this does the same.
panBy
  :: XYPosition
  -> Maybe PanZoomInstance
  -> Transform
  -> CoordinateExtent
  -> Number
  -> Number
  -> Aff Boolean
panBy delta mPanZoom (Transform t) translateExtent width height =
  case mPanZoom of
    Nothing -> pure false
    Just pz ->
      if delta.x == 0.0 && delta.y == 0.0 then pure false
      else do
        next <- pz.setViewportConstrained
          { x: t.tx + delta.x, y: t.ty + delta.y, zoom: t.scale }
          ( CoordinateExtent
              { minX: 0.0, minY: 0.0, maxX: width, maxY: height }
          )
          translateExtent
        pure case next of
          Nothing -> false
          Just zt ->
            zoomTransformX zt /= t.tx
              || zoomTransformY zt /= t.ty
              || zoomTransformK zt /= t.scale
