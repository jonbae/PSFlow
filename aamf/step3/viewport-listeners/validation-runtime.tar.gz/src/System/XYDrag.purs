-- | Node drag controller — port of
-- | `xyflow/packages/system/src/xydrag/XYDrag.ts`.
-- |
-- | The TS `XYDrag` is a factory that captures mutable state (`lastPos`,
-- | `dragItems`, `autoPanId`, …) in a closure and returns an object with
-- | `update`/`destroy` methods. The PS port collapses that state into a
-- | plain `DragState` record and lifts the lifecycle handlers (`onStart`,
-- | `onDragHandler`, `onEnd`, `startDrag`, `autoPan`, `updateNodes`) to
-- | `StateT DragState Effect`. A single outer `Ref DragState` carries the
-- | snapshot across the d3-callback boundary via `runOnRef`. d3-drag
-- | wiring goes through `System.FFI.D3Drag`.
-- |
-- | Type-parameter divergence from TS: the TS source has a single
-- | `<OnNodeDrag>` parameter that abstracts the user callback shape.
-- | `NodeBase`/`EdgeBase` are referenced unparameterized (effectively `<any>`).
-- | The PS equivalents are parameterized (`NodeBase nodeData`,
-- | `EdgeBase edgeData`), so the port threads two parameters through the
-- | store and the params record.
module System.XYDrag
  ( DragUpdateParams
  , DragStoreItems
  , XYDragParams
  , XYDragInstance
  , OnDrag
  , OnNodeDrag
  , OnSelectionDrag
  , PanBy
  , UpdateNodePositions
  , createXYDrag
  , startDrag
  , updateNodes
  , DragState
  , initialDragState
  , autoPanLoop
  ) where

import Prelude

import Control.Lazy (defer)
import Control.Monad.Except (runExcept)
import Control.Monad.State (StateT, get, modify_, runStateT)
import Data.Either (Either(..))
import Data.Foldable (for_, traverse_)
import Data.Array (any, length) as Array
import Data.Map (lookup) as Map
import Data.Maybe (Maybe(..), fromMaybe, isNothing)
import Data.Number (sqrt)
import Data.Tuple (Tuple(..))
import Effect (Effect)
import Effect.Aff (Aff, launchAff_)
import Effect.Class (liftEffect)
import Effect.Ref (Ref)
import Effect.Ref as Ref
import Foreign (Foreign, unsafeReadTagged)
import Unsafe.Coerce (unsafeCoerce)
import Web.DOM.Element (Element)
import Web.TouchEvent.TouchEvent (TouchEvent)
import Web.UIEvent.MouseEvent (MouseEvent)
import System.FFI.AnimationFrame
  ( RafHandle
  , cancelAnimationFrame
  , requestAnimationFrame
  )
import System.FFI.D3Drag
  ( D3DragEvent
  , applyDrag
  , dragBehavior
  , dragSourceEvent
  , setDragClickDistance
  , setDragFilter
  , setDragOn
  )
import System.FFI.D3Selection
  ( D3Selection
  , d3Select
  , d3SelectionOnNull
  )
import System.FFI.Microtask (awaitMicrotask)
import System.Constants (ErrorCode, errorId, errorMessage)
import System.Types.Edge (EdgeBase)
import System.Types.Geometry
  ( CoordinateExtent
  , NodeOrigin
  , SnapGrid
  , Transform(..)
  , XYPosition
  )
import System.Types.Ids (NodeId)
import System.Types.Node
  ( NodeBase
  , NodeDragItem
  , NodeLookup
  , OnError
  )
import System.Utils.Dom
  ( DOMRect
  , elementBoundingRect
  , getEventPosition
  , getPointerPosition
  )
import System.Utils.General (calcAutoPan, roundHalfUp, snapPosition)
import System.Utils.Graph (calculateNodePosition)
import System.XYDrag.Utils
  ( calculateSnapOffset
  , getDragItems
  , getEventHandlerParams
  , hasSelector
  )

-- | TS `(event, dragItems, node, nodes) => void`.
type OnDrag nodeData =
  MouseEvent
  -> Array NodeDragItem
  -> NodeBase nodeData
  -> Array (NodeBase nodeData)
  -> Effect Unit

-- | TS `(event, node, nodes) => void`.
type OnNodeDrag nodeData =
  MouseEvent
  -> NodeBase nodeData
  -> Array (NodeBase nodeData)
  -> Effect Unit

-- | TS `(event, nodes) => void`.
type OnSelectionDrag nodeData =
  MouseEvent
  -> Array (NodeBase nodeData)
  -> Effect Unit

-- | TS `({ x, y }) => Promise<boolean>`.
type PanBy = XYPosition -> Aff Boolean

-- | TS `(items, dragging) => void`.
type UpdateNodePositions = Array NodeDragItem -> Boolean -> Effect Unit

-- | Per-node-element configuration applied via `XYDragInstance.update`.
type DragUpdateParams =
  { noDragClassName :: Maybe String
  , handleSelector :: Maybe String
  , isSelectable :: Boolean
  , nodeId :: Maybe NodeId
  , domNode :: Element
  , nodeClickDistance :: Number
  }

-- | The store snapshot the controller reads on every drag tick. TS uses a
-- | thunk `getStoreItems()`; PS uses `Effect`.
type DragStoreItems nodeData edgeData =
  { nodes :: Array (NodeBase nodeData)
  , nodeLookup :: NodeLookup nodeData
  , edges :: Array (EdgeBase edgeData)
  , nodeExtent :: CoordinateExtent
  , snapGrid :: SnapGrid
  , snapToGrid :: Boolean
  , nodeOrigin :: NodeOrigin
  , multiSelectionActive :: Boolean
  , domNode :: Maybe Element
  , transform :: Transform
  , autoPanOnNodeDrag :: Boolean
  , nodesDraggable :: Boolean
  , selectNodesOnDrag :: Boolean
  , nodeDragThreshold :: Number
  , panBy :: PanBy
  , unselectNodesAndEdges :: Effect Unit
  , onNodeDragStart :: Maybe (OnNodeDrag nodeData)
  , onNodeDrag :: Maybe (OnNodeDrag nodeData)
  , onNodeDragStop :: Maybe (OnNodeDrag nodeData)
  , onSelectionDragStart :: Maybe (OnSelectionDrag nodeData)
  , onSelectionDrag :: Maybe (OnSelectionDrag nodeData)
  , onSelectionDragStop :: Maybe (OnSelectionDrag nodeData)
  , updateNodePositions :: UpdateNodePositions
  , autoPanSpeed :: Maybe Number
  -- | Upstream's `getStoreItems()` hands `calculateNodePosition` the
  -- | store's `onError`.
  , onError :: Maybe OnError
  }

type XYDragParams nodeData edgeData =
  { getStoreItems :: Effect (DragStoreItems nodeData edgeData)
  , onDragStart :: Maybe (OnDrag nodeData)
  , onDrag :: Maybe (OnDrag nodeData)
  , onDragStop :: Maybe (OnDrag nodeData)
  , onNodeMouseDown :: Maybe (NodeId -> Effect Unit)
  , autoPanSpeed :: Maybe Number
  }

type XYDragInstance =
  { update :: DragUpdateParams -> Effect Unit
  , destroy :: Effect Unit
  }

-- | Plain-record closure state. Lifecycle handlers run as
-- | `StateT DragState Effect` and a single outer `Ref DragState`
-- | carries the snapshot across the d3-callback boundary via `runOnRef`.
-- | Mirrors the shape `System.XYHandle` uses for its drag lifecycle.
-- |
-- | `runOnRef` is not re-entrant: a nested call reads the snapshot the outer
-- | one has not yet written, and the outer write then discards the inner's.
-- | Anything that re-enters from a callback has to run after its caller has
-- | returned — see `autoPanStep`.
-- |
-- | Public for testing, with `initialDragState`.
type DragState =
  { lastPos :: { x :: Maybe Number, y :: Maybe Number }
  , autoPanId :: Maybe RafHandle
  , dragItems :: Array NodeDragItem
  , autoPanStarted :: Boolean
  , mousePosition :: XYPosition
  , containerBounds :: Maybe DOMRect
  , dragStarted :: Boolean
  , d3Selection :: Maybe D3Selection
  , abortDrag :: Boolean
  , nodePositionsChanged :: Boolean
  , dragEvent :: Maybe MouseEvent
  }

initialDragState :: DragState
initialDragState =
  { lastPos: { x: Nothing, y: Nothing }
  , autoPanId: Nothing
  , dragItems: []
  , autoPanStarted: false
  , mousePosition: { x: 0.0, y: 0.0 }
  , containerBounds: Nothing
  , dragStarted: false
  , d3Selection: Nothing
  , abortDrag: false
  , nodePositionsChanged: false
  , dragEvent: Nothing
  }

-- | Run a `StateT DragState Effect a` against an outer `Ref` and write
-- | the new state back. Forms the bridge from the d3-event `Effect`
-- | boundary (and rAF / aff callbacks) to the pure-state interior.
runOnRef :: forall a. Ref DragState -> StateT DragState Effect a -> Effect a
runOnRef ref st = do
  s0 <- Ref.read ref
  Tuple a s1 <- runStateT st s0
  Ref.write s1 ref
  pure a

-- | The d3 source event arrives as `Foreign`. We attempt a tag-check via
-- | `Foreign.unsafeReadTagged` and only fall back to `unsafeCoerce` (the
-- | original TS-equivalent pattern) when the runtime tag isn't a literal
-- | match — `PointerEvent` and other MouseEvent subtypes that d3 forwards
-- | won't read as exactly `"MouseEvent"`. The check is best-effort
-- | telemetry rather than a hard refusal so the drag stays uninterrupted.
foreignAsMouseEvent :: Foreign -> MouseEvent
foreignAsMouseEvent f = case runExcept (unsafeReadTagged "MouseEvent" f) of
  Right me -> me
  Left _ -> unsafeCoerce f

foreignAsTouchOrMouse :: Foreign -> Either MouseEvent TouchEvent
foreignAsTouchOrMouse f = case runExcept (unsafeReadTagged "TouchEvent" f) of
  Right te -> Right te
  Left _ -> Left (foreignAsMouseEvent f)

-- | TS `event.sourceEvent.type === 'touchmove' && event.sourceEvent.touches.length > 1`.
-- | Implemented in JS because PS's `TouchEvent` binding doesn't expose
-- | `touches.length` portably.
foreign import isMultiTouchSourceEvent :: Foreign -> Effect Boolean

-- | `event.button === 0` for left-click. Returns `true` when the button bit
-- | is unset (matches the TS `!event.button` truthy-check).
foreign import mouseButtonIsZero :: MouseEvent -> Effect Boolean

-- | `event.target as Element`.
foreign import mouseEventTarget :: MouseEvent -> Effect Element

-- TS `Math.round` rounds halves toward +∞; `Data.Int.round` rounds to even.
-- `System.Utils.General.roundHalfUp` is `Math.round`, and is imported above.

-- | Construct the controller. Allocates a single `Ref DragState` and
-- | returns the `update`/`destroy` interface. Subsequent `update` calls
-- | re-bind the d3 drag behavior on a (possibly new) DOM node. Each d3
-- | callback enters the StateT interior via `runOnRef stateRef`.
createXYDrag
  :: forall nodeData edgeData
   . XYDragParams nodeData edgeData
  -> Effect XYDragInstance
createXYDrag params = do
  stateRef <- Ref.new initialDragState

  let
    destroy :: Effect Unit
    destroy = do
      s <- Ref.read stateRef
      for_ s.d3Selection \sel -> d3SelectionOnNull sel ".drag"

    update :: DragUpdateParams -> Effect Unit
    update upd = do
      sel <- d3Select upd.domNode
      Ref.modify_ (_ { d3Selection = Just sel }) stateRef
      behavior <- dragBehavior
      _ <- setDragClickDistance upd.nodeClickDistance behavior
      _ <- setDragOn "start" (\ev -> runOnRef stateRef (onStart params upd ev)) behavior
      _ <- setDragOn "drag" (\ev -> runOnRef stateRef (onDragHandler params stateRef upd ev)) behavior
      _ <- setDragOn "end" (\ev -> runOnRef stateRef (onEnd params upd ev)) behavior
      _ <- setDragFilter (filterPredicate upd) behavior
      applyDrag sel behavior

  pure { update, destroy }

-- ----------------------------------------------------------------------------
-- Lifecycle handlers
-- ----------------------------------------------------------------------------

onStart
  :: forall n e
   . XYDragParams n e
  -> DragUpdateParams
  -> D3DragEvent
  -> StateT DragState Effect Unit
onStart params upd ev = do
  store <- liftEffect params.getStoreItems
  src <- liftEffect (dragSourceEvent ev)
  bounds <- liftEffect $ case store.domNode of
    Just el -> Just <$> elementBoundingRect el
    Nothing -> pure Nothing
  modify_ _
    { containerBounds = bounds
    , abortDrag = false
    , nodePositionsChanged = false
    , dragEvent = Just (foreignAsMouseEvent src)
    }
  when (store.nodeDragThreshold == 0.0) (startDrag params upd ev)
  pp <- liftEffect $ getPointerPosition (foreignAsTouchOrMouse src)
    { transform: store.transform
    , snapGrid: store.snapGrid
    , snapToGrid: store.snapToGrid
    , containerBounds: bounds
    }
  mp <- liftEffect $ getEventPosition (foreignAsTouchOrMouse src) bounds
  modify_ _
    { lastPos = { x: Just pp.x, y: Just pp.y }
    , mousePosition = mp
    }

onDragHandler
  :: forall n e
   . XYDragParams n e
  -> Ref DragState
  -> DragUpdateParams
  -> D3DragEvent
  -> StateT DragState Effect Unit
onDragHandler params stateRef upd ev = do
  store <- liftEffect params.getStoreItems
  src <- liftEffect (dragSourceEvent ev)
  s0 <- get
  pp <- liftEffect $ getPointerPosition (foreignAsTouchOrMouse src)
    { transform: store.transform
    , snapGrid: store.snapGrid
    , snapToGrid: store.snapToGrid
    , containerBounds: s0.containerBounds
    }
  modify_ _ { dragEvent = Just (foreignAsMouseEvent src) }

  multi <- liftEffect (isMultiTouchSourceEvent src)
  let
    deletedDuringDrag = case upd.nodeId of
      Just nid -> isNothing (Map.lookup nid store.nodeLookup)
      Nothing -> false
  when (multi || deletedDuringDrag) (modify_ _ { abortDrag = true })

  s1 <- get
  when (not s1.abortDrag) do
    when (not s1.autoPanStarted && store.autoPanOnNodeDrag && s1.dragStarted) do
      modify_ _ { autoPanStarted = true }
      autoPanStep params upd.nodeId stateRef

    when (not s1.dragStarted) do
      curMP <- liftEffect $ getEventPosition (foreignAsTouchOrMouse src) s1.containerBounds
      let
        dx = curMP.x - s1.mousePosition.x
        dy = curMP.y - s1.mousePosition.y
        dist = sqrt (dx * dx + dy * dy)
      when (dist > store.nodeDragThreshold) (startDrag params upd ev)

    s2 <- get
    let moved = s2.lastPos.x /= Just pp.xSnapped || s2.lastPos.y /= Just pp.ySnapped
    when (moved && Array.length s2.dragItems > 0 && s2.dragStarted) do
      mp <- liftEffect $ getEventPosition (foreignAsTouchOrMouse src) s2.containerBounds
      modify_ _ { mousePosition = mp }
      updateNodes params upd.nodeId { x: pp.x, y: pp.y }

onEnd
  :: forall n e
   . XYDragParams n e
  -> DragUpdateParams
  -> D3DragEvent
  -> StateT DragState Effect Unit
onEnd params upd ev = do
  src <- liftEffect (dragSourceEvent ev)
  s0 <- get
  unless (not s0.dragStarted || s0.abortDrag) do
    liftEffect (for_ s0.autoPanId cancelAnimationFrame)
    modify_ _
      { autoPanStarted = false
      , dragStarted = false
      , autoPanId = Nothing
      }
    when (Array.length s0.dragItems > 0) do
      store <- liftEffect params.getStoreItems
      when s0.nodePositionsChanged do
        liftEffect (store.updateNodePositions s0.dragItems false)
        modify_ _ { nodePositionsChanged = false }
      let
        mouseEv = foreignAsMouseEvent src
        eventArgs = getEventHandlerParams upd.nodeId s0.dragItems
          store.nodes
          false
      liftEffect do
        for_ eventArgs.currentNode \cn -> do
          for_ params.onDragStop \cb ->
            cb mouseEv s0.dragItems cn eventArgs.allNodes
          for_ store.onNodeDragStop \cb ->
            cb mouseEv cn eventArgs.allNodes
        when (isNothing upd.nodeId) do
          for_ store.onSelectionDragStop \cb ->
            cb mouseEv eventArgs.allNodes

-- | The `.filter` predicate gating drag start. Mirrors TS:
-- |   `!event.button && (no noDragClassName || !target.matches('.X'))
-- |                  && (no handleSelector || target.matches(sel))`.
filterPredicate
  :: DragUpdateParams
  -> D3DragEvent
  -> Effect Boolean
filterPredicate upd ev = do
  src <- dragSourceEvent ev
  let me = foreignAsMouseEvent src
  btnZero <- mouseButtonIsZero me
  notNoDrag <- case upd.noDragClassName of
    Nothing -> pure true
    Just cls -> do
      target <- mouseEventTarget me
      matches <- hasSelector target ("." <> cls) upd.domNode
      pure (not matches)
  matchesHandle <- case upd.handleSelector of
    Nothing -> pure true
    Just sel -> do
      target <- mouseEventTarget me
      hasSelector target sel upd.domNode
  pure (btnZero && notNoDrag && matchesHandle)

-- ----------------------------------------------------------------------------
-- startDrag, autoPan, updateNodes — shared implementation.
-- ----------------------------------------------------------------------------

startDrag
  :: forall n e
   . XYDragParams n e
  -> DragUpdateParams
  -> D3DragEvent
  -> StateT DragState Effect Unit
startDrag params upd ev = do
  store <- liftEffect params.getStoreItems
  src <- liftEffect (dragSourceEvent ev)
  modify_ _ { dragStarted = true }

  let
    deselectFirst =
      (not store.selectNodesOnDrag || not upd.isSelectable)
        && not store.multiSelectionActive
  liftEffect $ case upd.nodeId of
    Just nid | deselectFirst -> do
      let alreadySelected = case Map.lookup nid store.nodeLookup of
            Just n -> n.selected == Just true
            Nothing -> false
      when (not alreadySelected) store.unselectNodesAndEdges
    _ -> pure unit

  liftEffect $ case upd.nodeId of
    Just nid | upd.isSelectable && store.selectNodesOnDrag ->
      for_ params.onNodeMouseDown \cb -> cb nid
    _ -> pure unit

  -- Upstream's `nodeLookup` is the store's own `Map`, and the two calls
  -- above change the selection in it in place: `addSelectedNodes` and
  -- `unselectNodesAndEdges` set its nodes' `selected`. So its
  -- `getDragItems` sees the selection this drag just made. `store` is a
  -- snapshot from before the calls, so the lookup is read again.
  latest <- liftEffect params.getStoreItems
  s <- get
  pp <- liftEffect $ getPointerPosition (foreignAsTouchOrMouse src)
    { transform: store.transform
    , snapGrid: store.snapGrid
    , snapToGrid: store.snapToGrid
    , containerBounds: s.containerBounds
    }

  let
    items = getDragItems (map _.id latest.nodes) latest.nodeLookup
      store.nodesDraggable
      { x: pp.x, y: pp.y }
      upd.nodeId
  modify_ _
    { lastPos = { x: Just pp.x, y: Just pp.y }
    , dragItems = items
    }

  when (Array.length items > 0) do
    let
      -- Upstream reports each item's `internals.userNode`, which the
      -- selection above reaches only when the flow applies it to its own
      -- nodes, as an uncontrolled one does at once.
      eventArgs = getEventHandlerParams upd.nodeId items latest.nodes true
      mouseEv = foreignAsMouseEvent src
    liftEffect do
      for_ eventArgs.currentNode \cn -> do
        for_ params.onDragStart \cb ->
          cb mouseEv items cn eventArgs.allNodes
        for_ store.onNodeDragStart \cb ->
          cb mouseEv cn eventArgs.allNodes
      when (isNothing upd.nodeId) do
        for_ store.onSelectionDragStart \cb ->
          cb mouseEv eventArgs.allNodes

-- | One auto-pan frame, as `requestAnimationFrame` runs it.
-- |
-- | The loop refers to itself — `autoPanStep` asks for the next frame by
-- | building this `Effect` — and PureScript is strict, so the step is
-- | `defer`red. Without it, building one frame builds the step, which builds
-- | the next frame, until the stack runs out: at the first drag event, inside
-- | d3's handler, before `runOnRef` has written anything back, so the node
-- | never moves. `System.XYHandle` breaks the same cycle by eta-expansion.
-- |
-- | Public for testing.
autoPanLoop
  :: forall n e
   . XYDragParams n e
  -> Maybe NodeId
  -> Ref DragState
  -> Effect Unit
autoPanLoop params mNodeId stateRef =
  runOnRef stateRef (defer \_ -> autoPanStep params mNodeId stateRef)

-- | TS `autoPan`. Near an edge it pans, waits for the pan to land, moves the
-- | dragged nodes by the distance panned, and only then asks for the next
-- | frame; elsewhere it asks straight away. One pan is in flight at most.
-- |
-- | The wait is `awaitMicrotask` as well as the `panBy` bind. ps-flow's
-- | `panBy` completes synchronously, and an `Aff` bound after a synchronous
-- | one continues on the same stack — here, inside the `runOnRef` of the drag
-- | handler or frame that called this step. The continuation would read the
-- | state as it stood before that caller began, and its writes would be lost
-- | when the caller wrote back. The next frame's handle is one of them, which
-- | leaves `onEnd` cancelling a frame that has already run while the loop
-- | carries on. TS gets the same yield from `await`.
-- |
-- | The node id is the grabbed node of the drag that started the loop, and it
-- | rides every frame. TS gets it from scope: `autoPan` is a closure inside
-- | `update({ nodeId, … })`, so a frame reports against the same node as the
-- | pointer-driven steps around it. Passing `Nothing` here instead would make
-- | `getEventHandlerParams` take whichever drag item sorts first and fire
-- | `onSelectionDrag`, which TS reserves for a selection drag.
autoPanStep
  :: forall n e
   . XYDragParams n e
  -> Maybe NodeId
  -> Ref DragState
  -> StateT DragState Effect Unit
autoPanStep params mNodeId stateRef = do
  s <- get
  case s.containerBounds of
    Nothing -> pure unit
    Just b -> do
      store <- liftEffect params.getStoreItems
      if not store.autoPanOnNodeDrag then do
        liftEffect (for_ s.autoPanId cancelAnimationFrame)
        modify_ _ { autoPanStarted = false, autoPanId = Nothing }
      else do
        let
          speed = fromMaybe 15.0 store.autoPanSpeed
          mv = calcAutoPan s.mousePosition
            { width: b.width, height: b.height }
            speed
            40.0
          Transform t = store.transform
        if mv.x /= 0.0 || mv.y /= 0.0 then do
          let
            newLp =
              { x: Just ((fromMaybe 0.0 s.lastPos.x) - mv.x / t.scale)
              , y: Just ((fromMaybe 0.0 s.lastPos.y) - mv.y / t.scale)
              }
          modify_ _ { lastPos = newLp }
          liftEffect $ launchAff_ do
            ok <- store.panBy { x: mv.x, y: mv.y }
            awaitMicrotask
            liftEffect $ runOnRef stateRef do
              when ok do
                s2 <- get
                case xyOf s2.lastPos of
                  Just xy -> updateNodes params mNodeId xy
                  Nothing -> pure unit
              scheduleNextFrame
        else scheduleNextFrame
  where
  scheduleNextFrame = do
    handle <- liftEffect $ requestAnimationFrame (autoPanLoop params mNodeId stateRef)
    modify_ _ { autoPanId = Just handle }
  xyOf r = case r.x, r.y of
    Just x, Just y -> Just { x, y }
    _, _ -> Nothing

updateNodes
  :: forall n e
   . XYDragParams n e
  -> Maybe NodeId
  -> XYPosition
  -> StateT DragState Effect Unit
updateNodes params mNodeId pos = do
  store <- liftEffect params.getStoreItems
  modify_ _ { lastPos = { x: Just pos.x, y: Just pos.y } }

  s <- get
  let
    items = s.dragItems
    isMultiDrag = Array.length items > 1
    multiSnap =
      if isMultiDrag && store.snapToGrid then
        calculateSnapOffset items store.snapGrid pos.x pos.y
      else Nothing

    -- One iteration: compute the next position with `calculateNodePosition`,
    -- and record whether the node moved.
    step :: NodeDragItem -> { item :: NodeDragItem, moved :: Boolean, errors :: Array ErrorCode }
    step dragItem = case Map.lookup dragItem.id store.nodeLookup of
      Nothing -> { item: dragItem, moved: false, errors: [] }
      Just _ ->
        let
          stepNext = case multiSnap of
            Just off ->
              { x: roundHalfUp ((pos.x - dragItem.distance.x) + off.x)
              , y: roundHalfUp ((pos.y - dragItem.distance.y) + off.y)
              }
            Nothing ->
              if store.snapToGrid then
                snapPosition
                  { x: pos.x - dragItem.distance.x
                  , y: pos.y - dragItem.distance.y
                  }
                  store.snapGrid
              else
                { x: pos.x - dragItem.distance.x
                , y: pos.y - dragItem.distance.y
                }
        in
          case
            calculateNodePosition
              { nodeId: dragItem.id
              , nextPosition: stepNext
              , nodeLookup: store.nodeLookup
              , nodeOrigin: store.nodeOrigin
              , nodeExtent: Just store.nodeExtent
              }
            of
            Nothing -> { item: dragItem, moved: false, errors: [] }
            -- Persist the computed coordinates back into the drag item (TS
            -- mutates `dragItem.position` / `dragItem.internals.positionAbsolute`);
            -- the live store dispatch below and the drag-end commit read from
            -- `dragItems`, so without this the node never actually moves.
            Just r ->
              { item: dragItem
                  { position = r.position
                  , internals = dragItem.internals
                      { positionAbsolute = r.positionAbsolute }
                  }
              , moved:
                  (r.position.x /= dragItem.position.x)
                    || (r.position.y /= dragItem.position.y)
              , errors: r.errors
              }

    stepped = map step items
    hasChange = Array.any _.moved stepped

  -- Upstream's loop raises each item's errors from `calculateNodePosition`
  -- as it goes, before it updates any position.
  liftEffect $ for_ stepped \st -> for_ st.errors \e ->
    for_ store.onError \cb -> cb (errorId e) (errorMessage e)

  modify_ _ { dragItems = map _.item stepped }

  when hasChange do
    modify_ _ { nodePositionsChanged = true }
    s2 <- get
    liftEffect (store.updateNodePositions s2.dragItems true)
    liftEffect $ traverse_
      ( \ev -> do
          let
            eventArgs = getEventHandlerParams mNodeId s2.dragItems store.nodes true
          for_ eventArgs.currentNode \cn -> do
            for_ params.onDrag \cb -> cb ev s2.dragItems cn eventArgs.allNodes
            for_ store.onNodeDrag \cb -> cb ev cn eventArgs.allNodes
          when (isNothing mNodeId) do
            for_ store.onSelectionDrag \cb -> cb ev eventArgs.allNodes
      )
      s2.dragEvent
