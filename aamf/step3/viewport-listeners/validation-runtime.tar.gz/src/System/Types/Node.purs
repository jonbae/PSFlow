module System.Types.Node
  ( NodeBaseRow
  , NodeBase
  , InternalNodeBase
  , NodeInternals
  , rememberUserNode
  , originalUserNode
  , userNodeIdentity
  , NodeHandleBounds
  , NodeBounds
  , NodeDragItem
  , NodeProps
  , NodeHandle
  , NodeExtent(..)
  , Align(..)
  , NodeLookup
  , ParentLookup
  , SetAttributesMode
  , NodeChange(..)
  , InternalNodeUpdate
  , OnError
  , ParentExpandChild
  ) where

import Prelude

import Data.Enum (class BoundedEnum, class Enum, Cardinality(..))
import Data.Enum.Generic (genericFromEnum, genericPred, genericSucc, genericToEnum)
import Data.Generic.Rep (class Generic)
import Data.Function.Uncurried (Fn2)
import Data.Map (Map)
import Data.Maybe (Maybe, fromMaybe)
import Data.Nullable (Nullable, toMaybe)
import Data.Show.Generic (genericShow)
import Effect (Effect)
import Foreign.Object (Object)
import Foreign (Foreign)
import Unsafe.Coerce (unsafeCoerce)
import Web.HTML.HTMLDivElement (HTMLDivElement)
import System.Types.Geometry
  ( CoordinateExtent
  , Dimensions
  , NodeOrigin
  , Position
  , Rect
  , XYPosition
  )
import System.Types.Handle (HandleIdField, HandleType, SourceHandle, TargetHandle)
import System.Types.Ids (NodeId, ParentId)

-- | The shared row of `NodeBase` fields. `InternalNodeBase` extends this
-- | with `internals`, so `toBaseLike`-style copies and the previously-
-- | duplicated 26-field record literals are no longer needed.
-- |
-- | TS field `type` is renamed to `nodeType` for internal consistency with the
-- | `nodeTypes` lookup map it indexes into — *not* because `type` is unusable:
-- | PureScript accepts `type` as a record label (see `React.Types.Nodes`,
-- | whose `NodeProps` declares `type :: String`). Realigning this field with
-- | upstream behind a marshalling layer is ticket 072.
-- |
-- | The type tag is a runtime string (`Maybe String`) rather than a phantom
-- | type since node types are user-defined runtime values.
type NodeBaseRow nodeData =
  ( id :: NodeId
  , position :: XYPosition
  , data :: nodeData
  , sourcePosition :: Maybe Position
  , targetPosition :: Maybe Position
  -- | Absent unless the consumer sets it, as upstream's optional field is.
  -- | Every reader treats absent as `false`.
  , hidden :: Maybe Boolean
  -- | Absent until a selection change sets it, as upstream's optional field
  -- | is. Every reader treats absent as `false`.
  , selected :: Maybe Boolean
  -- | Absent until a position change that carries it sets it, as upstream's
  -- | optional field is. Every reader treats absent as `false`.
  , dragging :: Maybe Boolean
  , draggable :: Maybe Boolean
  , selectable :: Maybe Boolean
  , connectable :: Maybe Boolean
  , deletable :: Maybe Boolean
  , dragHandle :: Maybe String
  , width :: Maybe Number
  , height :: Maybe Number
  , initialWidth :: Maybe Number
  , initialHeight :: Maybe Number
  , parentId :: Maybe ParentId
  , zIndex :: Maybe Int
  , extent :: Maybe NodeExtent
  -- | Absent unless the consumer sets it, as upstream's optional field is:
  -- | upstream builds an internal node from `{ ...defaults, ...userNode }`,
  -- | and every reader treats absent as `false`.
  , expandParent :: Maybe Boolean
  , ariaLabel :: Maybe String
  , origin :: Maybe NodeOrigin
  , handles :: Maybe (Array NodeHandle)
  , measured :: { width :: Maybe Number, height :: Maybe Number }
  , nodeType :: Maybe String
  , className :: Maybe String
  , style :: Maybe (Object String)
  )

type NodeBase nodeData = { | NodeBaseRow nodeData }

-- | Retain the actual original typed node. JS boundary decoding additionally
-- | associates that record with its original JS object, so equality compares
-- | consumer references rather than freshly allocated decoded records.
type NodeInternals nodeData =
  { positionAbsolute :: XYPosition
  , z :: Number
  , rootParentIndex :: Maybe Int
  , handleBounds :: Maybe NodeHandleBounds
  , bounds :: Maybe NodeBounds
  , userNode :: NodeBase nodeData
  }

foreign import rememberUserNode :: forall n. Fn2 Foreign (NodeBase n) (NodeBase n)
foreign import originalUserNode :: forall n. NodeBase n -> Nullable Foreign

userNodeIdentity :: forall n. NodeBase n -> Foreign
userNodeIdentity node = fromMaybe (unsafeCoerce node) (toMaybe (originalUserNode node))

-- | The same shape as `NodeBase` plus an `internals` field. Defined as a
-- | row-extension of `NodeBaseRow` to avoid the 26-field duplication that
-- | the previous flat encoding required.
type InternalNodeBase nodeData =
  { internals :: NodeInternals nodeData | NodeBaseRow nodeData }

-- | Source/target handle bounds. The outer optionality on `NodeHandleBounds`
-- | itself (`Maybe NodeHandleBounds`) carries the "not yet parsed"
-- | distinction; the inner arrays use the empty case for "parsed, no
-- | handles of this side". Three nesting levels of optionality collapsed
-- | to one.
-- |
-- | The inner arrays are typed with the phantom newtypes `SourceHandle` /
-- | `TargetHandle` so that consumers can't accidentally pass the target
-- | array where a source array is expected. Smart constructors
-- | `mkSourceHandle` / `mkTargetHandle` validate at the construction
-- | boundary (`parseHandles`, `toHandleBounds`, the DOM-driven
-- | `processUpdate`).
type NodeHandleBounds =
  { source :: Array SourceHandle
  , target :: Array TargetHandle
  }

type NodeBounds =
  { x :: Number
  , y :: Number
  , width :: Maybe Number
  , height :: Maybe Number
  }

type NodeDragItem =
  { id :: NodeId
  , position :: XYPosition
  , distance :: XYPosition
  , measured :: { width :: Number, height :: Number }
  , internals :: { positionAbsolute :: XYPosition }
  , extent :: Maybe NodeExtent
  , parentId :: Maybe ParentId
  , origin :: Maybe NodeOrigin
  , expandParent :: Maybe Boolean
  , dragging :: Maybe Boolean
  }

type NodeProps nodeData =
  { id :: NodeId
  , data :: nodeData
  , width :: Maybe Number
  , height :: Maybe Number
  , sourcePosition :: Maybe Position
  , targetPosition :: Maybe Position
  , dragHandle :: Maybe String
  , parentId :: Maybe ParentId
  , nodeType :: String
  , dragging :: Boolean
  , zIndex :: Int
  , selectable :: Boolean
  , deletable :: Boolean
  , selected :: Boolean
  , draggable :: Boolean
  , isConnectable :: Boolean
  , positionAbsoluteX :: Number
  , positionAbsoluteY :: Number
  }

-- | `Handle` minus `nodeId`, with `width`/`height` made optional.
type NodeHandle =
  { id :: HandleIdField
  , x :: Number
  , y :: Number
  , position :: Position
  , handleType :: HandleType
  , width :: Maybe Number
  , height :: Maybe Number
  }

data NodeExtent
  = ParentExtent
  | CoordExtent CoordinateExtent

derive instance eqNodeExtent :: Eq NodeExtent
derive instance genericNodeExtent :: Generic NodeExtent _

instance showNodeExtent :: Show NodeExtent where
  show = genericShow

data Align = AlignCenter | AlignStart | AlignEnd

derive instance eqAlign :: Eq Align
derive instance ordAlign :: Ord Align
derive instance genericAlign :: Generic Align _

instance showAlign :: Show Align where
  show = genericShow

instance boundedAlign :: Bounded Align where
  bottom = AlignCenter
  top = AlignEnd

instance enumAlign :: Enum Align where
  succ = genericSucc
  pred = genericPred

instance boundedEnumAlign :: BoundedEnum Align where
  cardinality = Cardinality 3
  toEnum = genericToEnum
  fromEnum = genericFromEnum

type NodeLookup nodeData = Map NodeId (InternalNodeBase nodeData)

type ParentLookup nodeData =
  Map ParentId (Map NodeId (InternalNodeBase nodeData))

-- | The TS `boolean | 'width' | 'height'` 4-value type collapses to a
-- | `Maybe { width, height }` — `Nothing` means "no set", a `Just` carries
-- | the per-axis flags. The previous `SetAttributesMode` 4-ctor data type
-- | is gone (ticket 021 #11).
type SetAttributesMode = Maybe { width :: Boolean, height :: Boolean }

-- | The TS `type: 'dimensions' | 'position' | ...` discriminant disappears —
-- | the constructor is the tag.
data NodeChange nodeData
  = NodeDimensionChange
      { id :: NodeId
      , dimensions :: Maybe Dimensions
      -- | Upstream's is optional: `NodeResizeControl`'s dimension changes
      -- | carry it, and `updateNodeInternals`' and `handleExpandParent`'s
      -- | don't.
      , resizing :: Maybe Boolean
      , setAttributes :: SetAttributesMode
      }
  | NodePositionChange
      { id :: NodeId
      , position :: Maybe XYPosition
      , positionAbsolute :: Maybe XYPosition
      -- | Upstream's is optional: the store's position changes carry it, and
      -- | `NodeResizeControl`'s and `handleExpandParent`'s don't.
      , dragging :: Maybe Boolean
      }
  | NodeSelectionChange
      { id :: NodeId
      , selected :: Boolean
      }
  | NodeRemoveChange
      { id :: NodeId }
  | NodeAddChange
      { item :: NodeBase nodeData
      , index :: Maybe Int
      }
  | NodeReplaceChange
      { id :: NodeId
      , item :: NodeBase nodeData
      }

-- | Used by the store reconciliation pipeline to push a measured DOM element
-- | back into a node. `force` opts out of the dimension-equality short-circuit.
type InternalNodeUpdate =
  { id :: NodeId
  , nodeElement :: HTMLDivElement
  , force :: Boolean
  }

-- | Error reporting callback. Maps the TS `OnError = (id, msg) => void` to
-- | a curried `Effect`-returning function. Callers wrap in `Maybe` when the
-- | callback is optional.
type OnError = String -> String -> Effect Unit

-- | Records that a child node has expanded its parent. Consumed by
-- | `handleExpandParent` and produced by `updateNodeInternals`.
type ParentExpandChild =
  { id :: NodeId
  , parentId :: ParentId
  , rect :: Rect
  }
