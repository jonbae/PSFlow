-- | `<NodesSelection />` — the bounding-box overlay around currently
-- | selected nodes. Draggable as a group; arrow-key nudge moves all
-- | selected nodes. Mirrors
-- | `xyflow/packages/react/src/components/NodesSelection/index.tsx`.
-- |
-- | Responsibilities:
-- |
-- |   1. Project the bounding-box geometry + transform string of the
-- |      currently selected nodes via `useStore`. The selector calls
-- |      `getInternalNodesBounds` filtered to `node.selected = true`.
-- |   2. Hide (`mempty`) when a user lasso is active or the bounds
-- |      aren't finite numbers. An empty selection's bounds are 0 by 0,
-- |      which renders, as upstream's `width !== null` does.
-- |   3. Mount `useDrag` with `nodeId = Nothing` so the XYDrag
-- |      controller takes the selection-drag branch (its `isNothing
-- |      nodeId` predicate gates `onSelectionDrag*` callbacks).
-- |   4. Mount `useMoveSelectedNodes` to drive arrow-key nudges.
-- |   5. Render two nested `<div>`s: an outer transform-positioned
-- |      wrapper and an inner sized rectangle that carries the drag
-- |      ref, context-menu handler, and keyboard handler.
-- |
-- | **Fidelity notes.**
-- |   * `useDrag` is always called (rules-of-hooks), and is disabled
-- |     when `shouldRender = false`, as upstream's is.
-- |   * The "virtual node id `__nodes_selection__`" suggested by the
-- |     ticket text isn't present in the TS source — TS passes no
-- |     `nodeId` at all, and the XYDrag controller routes the absence
-- |     to its selection-drag branch. We follow the TS behaviour.
-- |   * Autofocus on mount uses a small foreign helper
-- |     (`focusWithoutScrollImpl`) because there is no PS binding for
-- |     `HTMLElement.focus({ preventScroll })` yet.
module React.Component.NodesSelection
  ( nodesSelection
  ) where

import Prelude

import Data.Array (filter) as Array
import Data.Foldable (for_)
import Data.Map (lookup) as Map
import Data.Maybe (Maybe(..))
import Data.Newtype (unwrap)
import Data.Nullable (Nullable, toNullable)
import Data.Number (isFinite, isNaN) as Number
import Data.Number.Format (toString) as NumberFormat
import Effect (Effect)
import Effect.Unsafe (unsafePerformEffect)
import Foreign (Foreign)
import React.Basic (ReactComponent)
import React.Basic.Events (EventHandler, handler, handler_, syntheticEvent)
import React.Basic.Hooks (UnsafeReference(..), memo, reactComponent, readRef, useEffect, useRef)
import React.Basic.Hooks as React
import React.Component.NodeWrapper.Util (arrowKeyDiffs)
import React.FFI.DOM (div_)
import React.Hook.Drag (useDrag)
import React.Hook.MoveSelectedNodes (useMoveSelectedNodes)
import React.Hook.Store (UseStoreApi, useStore, useStoreApi)
import React.Store.Action (Action(..))
import React.Store.PanBy as StorePanBy
import React.Store.Shell (Store)
import React.Types.Component (NodesSelectionProps)
import React.Types.Store (ReactFlowState)
import System.Utils.Graph (getInternalNodesBounds)
import System.XYDrag (DragStoreItems)
import Unsafe.Coerce (unsafeCoerce)
import Web.Event.Event (preventDefault)
import Web.HTML.HTMLDivElement (HTMLDivElement, toElement)
import Web.UIEvent.KeyboardEvent (KeyboardEvent)
import Web.UIEvent.KeyboardEvent (key, shiftKey, toEvent) as KE
import Web.UIEvent.MouseEvent (MouseEvent)

foreign import focusWithoutScrollImpl :: Nullable HTMLDivElement -> Effect Unit

toForeignStyle :: forall r. Record r -> Foreign
toForeignStyle = unsafeCoerce

showN :: Number -> String
showN = NumberFormat.toString

isNumericN :: Number -> Boolean
isNumericN n = not (Number.isNaN n) && Number.isFinite n

-- ----------------------------------------------------------------------------
-- Slice
-- ----------------------------------------------------------------------------

type NodesSelectionSlice =
  { width :: Number
  , height :: Number
  , hasBounds :: Boolean
  , transformString :: String
  , userSelectionActive :: Boolean
  }

selectSlice :: forall n e. ReactFlowState n e -> NodesSelectionSlice
selectSlice s =
  let
    rect = getInternalNodesBounds s.nodeLookup (Just \n -> n.selected == Just true)
    t = unwrap s.transform
    transformString =
      "translate(" <> showN t.tx <> "px," <> showN t.ty <> "px)"
        <> " scale(" <> showN t.scale <> ")"
        <> " translate(" <> showN rect.x <> "px," <> showN rect.y <> "px)"
  in
    { width: rect.width
    , height: rect.height
    , hasBounds: isNumericN rect.width && isNumericN rect.height
    , transformString
    , userSelectionActive: s.userSelectionActive
    }

-- ----------------------------------------------------------------------------
-- Drag-store-items adapter (local copy; see plan)
-- ----------------------------------------------------------------------------

mkDragStoreItems
  :: forall n e
   . Store n e
  -> Effect (DragStoreItems n e)
mkDragStoreItems store = do
  s <- store.getState
  pure
    { nodes: s.nodes
    , nodeLookup: s.nodeLookup
    , edges: s.edges
    , nodeExtent: s.nodeExtent
    , snapGrid: s.snapGrid
    , snapToGrid: s.snapToGrid
    , nodeOrigin: s.nodeOrigin
    , multiSelectionActive: s.multiSelectionActive
    , domNode: map toElement s.domNode
    , transform: s.transform
    , autoPanOnNodeDrag: s.autoPanOnNodeDrag
    , nodesDraggable: s.nodesDraggable
    , selectNodesOnDrag: s.selectNodesOnDrag
    , nodeDragThreshold: s.nodeDragThreshold
    , panBy: StorePanBy.panBy store
    , unselectNodesAndEdges:
        store.dispatch
          (UnselectNodesAndEdges { nodes: Nothing, edges: Nothing })
    , onNodeDragStart: s.onNodeDragStart
    , onNodeDrag: s.onNodeDrag
    , onNodeDragStop: s.onNodeDragStop
    , onSelectionDragStart: s.onSelectionDragStart
    , onSelectionDrag: s.onSelectionDrag
    , onSelectionDragStop: s.onSelectionDragStop
    , updateNodePositions: \items dragging ->
        store.dispatch
(UpdateNodePositions items dragging)
    , autoPanSpeed: Just s.autoPanSpeed
    , onError: s.onError
    }

-- ----------------------------------------------------------------------------
-- The component
-- ----------------------------------------------------------------------------

nodesSelection :: forall n. ReactComponent (NodesSelectionProps n)
nodesSelection =
  unsafePerformEffect $ memo $ reactComponent "NodesSelection"
    \(props :: NodesSelectionProps n) -> React.do
      slice <- useStore selectSlice
      store <- (useStoreApi :: React.Hook UseStoreApi _)
      nodeRef <- useRef (toNullable Nothing :: Nullable HTMLDivElement)
      moveSelectedNodes <- useMoveSelectedNodes

      let
        shouldRender = not slice.userSelectionActive && slice.hasBounds

      useEffect (UnsafeReference props.disableKeyboardA11y) do
        unless props.disableKeyboardA11y do
          cur <- readRef nodeRef
          focusWithoutScrollImpl cur
        pure (pure unit)

      _dragging <- useDrag
        { wrapperRef: nodeRef
        , disabled: not shouldRender
        , nodeId: Nothing
        , noDragClassName: props.noPanClassName
        , handleSelector: Nothing
        , isSelectable: true
        , nodeClickDistance: 0.0
        , autoPanSpeed: Nothing
        , getStoreItems: mkDragStoreItems store
        , onDragStart: Nothing
        , onDragEnd: Nothing
        -- Selection drag has no single node to select on mouse-down.
        , onNodeMouseDown: Nothing
        }

      let
        wrapperClass =
          "react-flow__nodesselection react-flow__container"
            <> case props.noPanClassName of
                 Just c | c /= "" -> " " <> c
                 _ -> ""

        onContextMenuHandler :: EventHandler
        onContextMenuHandler = handler syntheticEvent \se -> do
          let me = (unsafeCoerce se) :: MouseEvent
          for_ props.onSelectionContextMenu \cb -> do
            st <- store.getState
            let selected = Array.filter (\n -> n.selected == Just true) st.nodes
            cb me selected

        onKeyDownHandler :: KeyboardEvent -> Effect Unit
        onKeyDownHandler ke = case Map.lookup (KE.key ke) arrowKeyDiffs of
          Just delta -> do
            preventDefault (KE.toEvent ke)
            moveSelectedNodes delta (if KE.shiftKey ke then 4.0 else 1.0)
          Nothing -> pure unit

        onKeyDownEventHandler :: EventHandler
        onKeyDownEventHandler = handler syntheticEvent \se ->
          onKeyDownHandler ((unsafeCoerce se) :: KeyboardEvent)

      pure $
        if not shouldRender then mempty
        else
          div_
            { className: wrapperClass
            , style: toForeignStyle { transform: slice.transformString }
            }
            [ div_
                { ref: nodeRef
                , className: "react-flow__nodesselection-rect"
                , onContextMenu: onContextMenuHandler
                -- TS: `disableKeyboardA11y ? undefined : -1`. React omits a
                -- `null` prop, as it does an `undefined` one.
                , tabIndex: toNullable (if props.disableKeyboardA11y then Nothing else Just (-1))
                , onKeyDown:
                    if props.disableKeyboardA11y then handler_ (pure unit)
                    else onKeyDownEventHandler
                -- Numbers, as TS's are, which React writes in pixels. A
                -- string with no unit is invalid CSS, which the browser drops.
                , style: toForeignStyle
                    { width: slice.width
                    , height: slice.height
                    }
                }
                []
            ]
