-- | Experimental middleware hooks. Each installs an interceptor in
-- | the store's middleware map; the reducer consults the map before
-- | dispatching the corresponding `Trigger*Changes` action so a
-- | registered function can drop, mutate, or pass through changes.
-- |
-- | Mirrors
-- | `xyflow/packages/react/src/hooks/useOnNodesChangeMiddleware.ts`
-- | and `useOnEdgesChangeMiddleware.ts`.
-- |
-- | **Storage strategy.** Each registration mints a fresh
-- | `MiddlewareKey` via `store.freshMiddlewareKey` and dispatches
-- | `AddOnNodesChangeMiddleware key fn` (or the edge equivalent). On
-- | unmount the same key is removed via `RemoveOnNodesChangeMiddleware`.
-- | The `MiddlewareKey` is captured in a `useRef` so unmount can find
-- | it again.
module React.Hook.Middleware
  ( UseMiddlewareHook(..)
  , useOnNodesChangeMiddleware
  , useOnEdgesChangeMiddleware
  ) where

import Prelude

import Data.Maybe (Maybe(..))
import Data.Newtype (class Newtype)
import React.Basic.Hooks (Hook, UnsafeReference(..), UseEffect, UseRef, coerceHook, readRef, useEffect, useRef, writeRef)
import React.Basic.Hooks as React
import React.Hook.Store (UseStoreApi, useStoreApi)
import React.Store.Action (Action(..))
import React.Types.Store (MiddlewareKey)
import System.Types.Edge (EdgeChange)
import System.Types.Node (NodeChange)

newtype UseMiddlewareHook fn hooks =
  UseMiddlewareHook
    ( UseEffect (UnsafeReference fn)
        ( UseRef (Maybe MiddlewareKey)
            (UseStoreApi hooks)
        )
    )

derive instance newtypeUseMiddlewareHook ::
  Newtype (UseMiddlewareHook fn hooks) _

-- | Register an interceptor on node-change dispatches for the lifetime
-- | of the calling component. The function receives every batch of
-- | `NodeChange n` headed for the reducer and may return a possibly
-- | filtered/transformed batch.
useOnNodesChangeMiddleware
  :: forall n
   . (Array (NodeChange n) -> Array (NodeChange n))
  -> Hook
       (UseMiddlewareHook (Array (NodeChange n) -> Array (NodeChange n)))
       Unit
useOnNodesChangeMiddleware fn = coerceHook React.do
  store <- (useStoreApi :: Hook UseStoreApi _)
  keyRef <- useRef (Nothing :: Maybe MiddlewareKey)
  useEffect (UnsafeReference fn) do
    key <- store.freshMiddlewareKey
    writeRef keyRef (Just key)
    store.dispatch (AddOnNodesChangeMiddleware key fn)
    pure do
      mKey <- readRef keyRef
      case mKey of
        Just k -> store.dispatch (RemoveOnNodesChangeMiddleware k)
        Nothing -> pure unit
      writeRef keyRef Nothing

-- | Edge-change counterpart. See `useOnNodesChangeMiddleware`.
useOnEdgesChangeMiddleware
  :: forall e
   . (Array (EdgeChange e) -> Array (EdgeChange e))
  -> Hook
       (UseMiddlewareHook (Array (EdgeChange e) -> Array (EdgeChange e)))
       Unit
useOnEdgesChangeMiddleware fn = coerceHook React.do
  store <- (useStoreApi :: Hook UseStoreApi _)
  keyRef <- useRef (Nothing :: Maybe MiddlewareKey)
  useEffect (UnsafeReference fn) do
    key <- store.freshMiddlewareKey
    writeRef keyRef (Just key)
    store.dispatch (AddOnEdgesChangeMiddleware key fn)
    pure do
      mKey <- readRef keyRef
      case mKey of
        Just k -> store.dispatch (RemoveOnEdgesChangeMiddleware k)
        Nothing -> pure unit
      writeRef keyRef Nothing

