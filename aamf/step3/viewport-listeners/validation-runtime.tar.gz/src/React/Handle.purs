-- | `<Handle />` — the connection point on a node. React-side wiring on
-- | top of `System.XYHandle.onPointerDown` / `System.XYHandle.isValid`.
-- | Mirrors `xyflow/packages/react/src/components/Handle/index.tsx`.
-- |
-- | This module is the React-layer twin of `System.XYHandle`: the system
-- | layer owns the pointer-drag state machine and the click-connect
-- | validity check, this module owns the React glue (event handlers,
-- | store reads, dispatch, visual-class flags).
-- |
-- | The wiring pattern matches
-- | `React.Component.EdgeWrapper.UpdateAnchors`, which solved the same
-- | "synthetic event -> XYHandle.onPointerDown" problem for reconnect
-- | drags. A few small helpers (`syntheticToMouse`, `currentTargetElement`,
-- | `extractFromHandle`) are duplicated here rather than extracted to a
-- | shared module — if a third caller appears, lift them. `panBy` was one of
-- | them and now comes from `React.Store.PanBy`, because a copy that answers
-- | `pure true` is a wrong answer four times over.
module React.Handle
  ( handle
  , clickConnectEndState
  , nativePointerEvent
  , startsConnection
  ) where

import Prelude

import Data.Array (uncons) as Array
import Data.Either (Either(..))
import Data.Foldable (for_)
import Data.Maybe (Maybe(..), fromMaybe, isJust, maybe)
import Effect (Effect)
import Effect.Exception.Unsafe (unsafeThrow)
import Effect.Unsafe (unsafePerformEffect)
import Foreign (Foreign)
import React.Basic (ReactComponent)
import React.Basic.Events (EventHandler, SyntheticEvent, handler, syntheticEvent)
import React.Basic.Hooks (memo, reactComponent)
import React.Basic.Hooks as React
import React.Context.NodeId (useNodeId)
import React.FFI.DOM (div_, opt)
import React.Hook.Store (UseStoreApi, useStore, useStoreApi)
import React.Store.Action (Action(..))
import React.Store.PanBy as StorePanBy
import React.Store.Shell (Store)
import React.Types.Component (HandleProps)
import React.Types.Edges (DefaultEdgeOptions)
import React.Types.General (IsValidConnection) as RG
import React.Types.Store (ReactFlowState, ConnectionClickStartHandle)
import System.Constants (ErrorCode(..), errorMessage)
import System.Types.Connection
  ( Connection
  , ConnectionMode(..)
  , ConnectionState(..)
  , FinalConnectionState
  )
import System.Types.Edge (EdgeBase)
import System.Types.Geometry (Position(..))
import System.Types.Handle (Handle, HandleIdField(..), HandleType(..))
import System.Types.Ids (NodeId(..))
import System.Utils.Dom (getHostForElement)
import System.Utils.Edges.General (addEdge, getEdgeId)
import System.XYHandle (xyHandle)
import Unsafe.Coerce (unsafeCoerce)
import Web.DOM.Element (Element)
import Web.TouchEvent.TouchEvent (TouchEvent)
import Web.Event.Event (currentTarget) as Event
import Web.UIEvent.MouseEvent (MouseEvent)
import Web.UIEvent.MouseEvent (button, toEvent) as ME

type HandleStoreSlice =
  { connectOnClick :: Boolean
  , noPanClassName :: String
  , rfId :: String
  }

selectHandleSlice :: forall n e. ReactFlowState n e -> HandleStoreSlice
selectHandleSlice s =
  { connectOnClick: s.connectOnClick
  , noPanClassName: s.noPanClassName
  , rfId: s.rfId
  }

-- | The seven visual-class flags. Mirrors TS `connectingSelector`.
-- | Record-of-Booleans satisfies `useStore`'s `Eq` constraint.
type ConnectingFlags =
  { connectingFrom :: Boolean
  , connectingTo :: Boolean
  , clickConnecting :: Boolean
  , isPossibleEndHandle :: Boolean
  , connectionInProcess :: Boolean
  , clickConnectionInProcess :: Boolean
  , valid :: Boolean
  }

selectConnectingFlags
  :: forall n e
   . NodeId
  -> Maybe String
  -> HandleType
  -> ReactFlowState n e
  -> ConnectingFlags
selectConnectingFlags nodeId handleId hType state =
  case state.connection of
    NoConnection ->
      { connectingFrom: false
      , connectingTo: false
      , clickConnecting
      , isPossibleEndHandle: case state.connectionClickStartHandle of
          Just s -> case state.connectionMode of
            Strict -> s.handleType /= hType
            Loose -> nodeId /= NodeId s.nodeId || handleId /= s.id
          Nothing -> false
      , connectionInProcess: false
      , clickConnectionInProcess
      , valid: false
      }
    ConnectionInProgress p ->
      let
        -- Upstream compares a handle's id with `===`, and this handle's id is
        -- `null` when it has none.
        ownId = maybe HandleIdNull HandleIdSet handleId
        fromMatches =
          p.fromHandle.nodeId == nodeId
            && p.fromHandle.id == ownId
            && p.fromHandle.handleType == hType
        toMatches = case p.toHandle of
          Just t -> t.nodeId == nodeId
            && t.id == ownId
            && t.handleType == hType
          Nothing -> false
      in
        { connectingFrom: fromMatches
        , connectingTo: toMatches
        , clickConnecting
        , isPossibleEndHandle: case state.connectionMode of
            Strict -> p.fromHandle.handleType /= hType
            Loose -> nodeId /= p.fromHandle.nodeId
              || ownId /= p.fromHandle.id
        , connectionInProcess: true
        , clickConnectionInProcess
        , valid: toMatches && p.isValid == Just true
        }
  where
  clickConnecting = case state.connectionClickStartHandle of
    Just s -> NodeId s.nodeId == nodeId
      && s.id == handleId
      && s.handleType == hType
    Nothing -> false

  clickConnectionInProcess = isJust state.connectionClickStartHandle

positionString :: Position -> String
positionString = case _ of
  PosLeft -> "left"
  PosRight -> "right"
  PosTop -> "top"
  PosBottom -> "bottom"

handleTypeString :: HandleType -> String
handleTypeString = case _ of
  Source -> "source"
  Target -> "target"

-- | Builds the space-separated `className` string mirroring the TS
-- | `cc([...])` output. Empty/false flags are dropped.
buildClassName
  :: { position :: Position
     , isTarget :: Boolean
     , isConnectable :: Boolean
     , isConnectableStart :: Boolean
     , isConnectableEnd :: Boolean
     , noPanClassName :: String
     , extra :: Maybe String
     , flags :: ConnectingFlags
     }
  -> String
buildClassName p =
  joinNonEmpty
    [ "react-flow__handle"
    , "react-flow__handle-" <> positionString p.position
    , "nodrag"
    , p.noPanClassName
    , fromMaybe "" p.extra
    , if p.isTarget then "target" else "source"
    , if p.isConnectable then "connectable" else ""
    , if p.isConnectableStart then "connectablestart" else ""
    , if p.isConnectableEnd then "connectableend" else ""
    , if p.flags.clickConnecting then "clickconnecting" else ""
    , if p.flags.connectingFrom then "connectingfrom" else ""
    , if p.flags.connectingTo then "connectingto" else ""
    , if p.flags.valid then "valid" else ""
    , if indicatorOn then "connectionindicator" else ""
    ]
  where
  inProcess = p.flags.connectionInProcess
  clickInProcess = p.flags.clickConnectionInProcess
  endSlotOk = if inProcess || clickInProcess then p.isConnectableEnd
  else p.isConnectableStart
  indicatorOn = p.isConnectable
    && (not inProcess || p.flags.isPossibleEndHandle)
    && endSlotOk

joinNonEmpty :: Array String -> String
joinNonEmpty = foldStrip ""
  where
  foldStrip acc as = case Array.uncons as of
    Nothing -> acc
    Just { head: "", tail } -> foldStrip acc tail
    Just { head, tail }
      | acc == "" -> foldStrip head tail
      | otherwise -> foldStrip (acc <> " " <> head) tail

-- ---------------------------------------------------------------------------
-- Local helpers — duplicates of the ones in
-- `React.Component.EdgeWrapper.UpdateAnchors`. Promote to a shared module if
-- a third caller appears.
-- ---------------------------------------------------------------------------

-- | The synthetic event, typed as the `MouseEvent` upstream casts it to
-- | (`event as unknown as MouseEvent`) for `onClickConnectEnd`. Everything
-- | else upstream's `<Handle />` hands on gets `nativePointerEvent`.
syntheticToMouse :: SyntheticEvent -> MouseEvent
syntheticToMouse = unsafeCoerce

foreign import hasClientX :: Foreign -> Boolean

-- | `event.nativeEvent`, the DOM event React's synthetic one wraps, which
-- | upstream hands to `XYHandle.onPointerDown`, `XYHandle.isValid`, and
-- | `onClickConnectStart`. It's split as upstream's `isMouseEvent` splits
-- | it: an event with a `clientX` is a mouse event, and any other a touch
-- | event.
nativePointerEvent :: SyntheticEvent -> Either MouseEvent TouchEvent
nativePointerEvent se =
  let
    native = (unsafeCoerce se :: { nativeEvent :: Foreign }).nativeEvent
  in
    if hasClientX native then Left (unsafeCoerce native) else Right (unsafeCoerce native)

-- | Upstream's guard on a pointer down:
-- |
-- |     isConnectableStart && ((isMouseTriggered && event.button === 0) || !isMouseTriggered)
-- |
-- | A mouse starts a connection with its main button only, and a touch
-- | always does.
startsConnection :: Boolean -> Either MouseEvent TouchEvent -> Boolean
startsConnection isConnectableStart = case _ of
  Left me -> isConnectableStart && ME.button me == 0
  Right _ -> isConnectableStart

currentTargetElement :: SyntheticEvent -> Maybe Element
currentTargetElement se =
  map unsafeCoerce
    (Event.currentTarget (ME.toEvent (syntheticToMouse se)))

extractFromHandle :: forall node. ConnectionState node -> Maybe Handle
extractFromHandle = case _ of
  NoConnection -> Nothing
  ConnectionInProgress p -> Just p.fromHandle

-- | Adapt a React-layer `IsValidConnection e` (record carrying
-- | `edge :: Maybe (Edge e)`) to the system-layer `Connection -> Boolean`
-- | shape that `XYHandle.onPointerDown` expects. During a fresh drag
-- | there's no candidate edge, so we pass `edge: Nothing`.
liftValidConn :: forall e. RG.IsValidConnection e -> Connection -> Boolean
liftValidConn iv conn = iv
  { source: conn.source
  , target: conn.target
  , sourceHandle: conn.sourceHandle
  , targetHandle: conn.targetHandle
  , edge: Nothing
  }

-- ---------------------------------------------------------------------------
-- onConnect: merge defaultEdgeOptions, dispatch SetEdges if hasDefaultEdges,
-- fire store + prop callbacks.
-- ---------------------------------------------------------------------------

connectionToEdge
  :: forall e
   . Maybe (DefaultEdgeOptions e)
  -> Connection
  -> EdgeBase e
connectionToEdge mDefaults conn =
  { id: getEdgeId conn
  , edgeType: Nothing
  , source: conn.source
  , target: conn.target
  , sourceHandle: conn.sourceHandle
  , targetHandle: conn.targetHandle
  , animated: _.animated =<< mDefaults
  , hidden: _.hidden =<< mDefaults
  , deletable: _.deletable =<< mDefaults
  , selectable: _.selectable =<< mDefaults
  , data: _.data =<< mDefaults
  , selected: Nothing
  , markerStart: Nothing
  , markerEnd: Nothing
  , zIndex: _.zIndex =<< mDefaults
  , label: Nothing
  , ariaLabel: _.ariaLabel =<< mDefaults
  , interactionWidth: _.interactionWidth =<< mDefaults
  , className: Nothing
  , style: Nothing
  }

-- | The reusable "user dropped a valid connection" path. Used by both
-- | drag (`onPointerDown` -> XYHandle -> onConnect cb) and click-connect
-- | step 2 (`onClick` -> XYHandle.isValid -> here).
onConnectExtended
  :: forall n e
   . Store n e
  -> Maybe (Connection -> Effect Unit)
  -> Connection
  -> Effect Unit
onConnectExtended store mPropOnConnect conn = do
  state <- store.getState
  when state.hasDefaultEdges do
    let
      edge = connectionToEdge state.defaultEdgeOptions conn
    case addEdge edge state.edges getEdgeId of
      Right next -> store.dispatch (SetEdges next)
      Left _ -> pure unit
  for_ state.onConnect \cb -> cb conn
  for_ mPropOnConnect \cb -> cb conn

-- ---------------------------------------------------------------------------
-- The component
-- ---------------------------------------------------------------------------

-- | The state the click handler hands `onClickConnectEnd`. TS:
-- |
-- |     connectionClone.toPosition = connectionClone.toHandle ? connectionClone.toHandle.position : null;
-- |
-- | `NoConnection`, the usual state between the two clicks, is upstream's
-- | all-`null` record.
clickConnectEndState :: forall node. ConnectionState node -> FinalConnectionState node
clickConnectEndState = case _ of
  NoConnection -> Nothing
  ConnectionInProgress p -> Just p { toPosition = map _.position p.toHandle }

handle :: ReactComponent HandleProps
handle = unsafePerformEffect $ memo $ reactComponent "Handle" \(props :: HandleProps) -> React.do
  slice <- useStore selectHandleSlice
  store <- (useStoreApi :: React.Hook UseStoreApi _)
  nodeIdM <- useNodeId
  let
    nodeIdStr = case nodeIdM of
      Just nid -> nid
      Nothing -> unsafeThrow (errorMessage E010)
    nodeId = NodeId nodeIdStr
    -- Upstream's `const handleId = id || null`: an empty id is no id.
    handleId = case props.id of
      Just "" -> Nothing
      other -> other
    handleType = props.handleType
  flags <- useStore (selectConnectingFlags nodeId handleId handleType)
  let
    isConnectable = fromMaybe true props.isConnectable
    isConnectableStart = fromMaybe true props.isConnectableStart
    isConnectableEnd = fromMaybe true props.isConnectableEnd
    isTarget = case handleType of
      Target -> true
      Source -> false
    className = buildClassName
      { position: props.position
      , isTarget
      , isConnectable
      , isConnectableStart
      , isConnectableEnd
      , noPanClassName: slice.noPanClassName
      , extra: props.className
      , flags
      }
    dataId = slice.rfId
      <> "-"
      <> nodeIdStr
      <> "-"
      -- Upstream's template literal writes a missing id as `null`, which
      -- is what `System.XYHandle.handleSelector` looks for.
      <> fromMaybe "null" handleId
      <> "-"
      <> handleTypeString handleType

    onPointerDown :: EventHandler
    onPointerDown = handler syntheticEvent \se -> do
      let event = nativePointerEvent se
      when (startsConnection isConnectableStart event) do
        state <- store.getState
        case currentTargetElement se of
          Nothing -> pure unit
          Just el -> xyHandle.onPointerDown event
            { autoPanOnConnect: state.autoPanOnConnect
            , connectionMode: state.connectionMode
            , connectionRadius: state.connectionRadius
            , domNode: state.domNode
            , handleId
            , nodeId
            , isTarget
            , nodeLookup: state.nodeLookup
            , lib: state.lib
            , flowId: Just state.rfId
            , edgeUpdaterType: Nothing
            , updateConnection: \cs -> store.dispatch (UpdateConnection cs)
            , panBy: StorePanBy.panBy store
            , cancelConnection: store.dispatch CancelConnection
            , onConnectStart: state.onConnectStart
            , onConnect: Just (onConnectExtended store props.onConnect)
            , onConnectEnd: state.onConnectEnd
            , isValidConnection: case props.isValidConnection of
                Just iv -> liftValidConn iv
                Nothing -> case state.isValidConnection of
                  Just iv -> liftValidConn iv
                  Nothing -> \_ -> true
            , onReconnectEnd: Nothing
            , getTransform: _.transform <$> store.getState
            , getFromHandle: do
                s <- store.getState
                pure (extractFromHandle s.connection)
            , autoPanSpeed: Just state.autoPanSpeed
            , dragThreshold: state.connectionDragThreshold
            , handleDomNode: el
            }

    onClick :: EventHandler
    onClick = handler syntheticEvent \se -> do
      let
        event = nativePointerEvent se
        me = syntheticToMouse se
      state <- store.getState
      let
        canStart = isConnectableStart
        haveStart = isJust state.connectionClickStartHandle
      when (canStart || haveStart) do
        case state.connectionClickStartHandle of
          Nothing -> do
            for_ state.onClickConnectStart \cb -> cb event
              { nodeId: Just nodeId
              , handleId
              , handleType: Just handleType
              }
            store.dispatch
              ( PatchState
                  ( _
                      { connectionClickStartHandle = Just
                          { nodeId: nodeIdStr
                          , id: handleId
                          , handleType
                          } :: Maybe ConnectionClickStartHandle
                      }
                  )
              )
          Just startHandle -> do
            host <- getHostForElement Nothing
            result <- xyHandle.isValid event
              { handle: Just
                  { nodeId
                  , id: maybe HandleIdNull HandleIdSet handleId
                  , handleType
                  }
              , connectionMode: state.connectionMode
              , fromNodeId: NodeId startHandle.nodeId
              , fromHandleId: startHandle.id
              , fromType: startHandle.handleType
              , isValidConnection: case props.isValidConnection of
                  Just iv -> liftValidConn iv
                  Nothing -> case state.isValidConnection of
                    Just iv -> liftValidConn iv
                    Nothing -> \_ -> true
              , doc: host
              , lib: state.lib
              , flowId: Just state.rfId
              , nodeLookup: state.nodeLookup
              }
            case result.isValid, result.connection of
              true, Just conn -> onConnectExtended store props.onConnect conn
              _, _ -> pure unit
            for_ state.onClickConnectEnd \cb -> cb (Left me) (clickConnectEndState state.connection)
            store.dispatch
              ( PatchState (_ { connectionClickStartHandle = Nothing }) )

  pure $ div_
    { className
    , ref: props.innerRef
    , style: opt props.style
    , "data-handleid": opt handleId
    , "data-nodeid": nodeIdStr
    , "data-handlepos": positionString props.position
    , "data-id": dataId
    , onMouseDown: onPointerDown
    , onTouchStart: onPointerDown
    , onClick: if slice.connectOnClick then onClick else handler syntheticEvent \_ -> pure unit
    }
    []
