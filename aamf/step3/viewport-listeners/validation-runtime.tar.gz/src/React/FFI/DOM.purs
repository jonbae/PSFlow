-- | Minimal SVG/HTML element FFI for the React-renderer tickets
-- | (032 — built-in edges, 033 — built-in nodes, 034 — `Handle`).
-- |
-- | Each binding is a thin wrapper over `React.createElement(tag, props,
-- | ...children)`. Props rows are untyped — callers pass plain records,
-- | JS-side spreads them onto the element. Type checking SVG attributes
-- | per-tag is deferred to a future migration to `react-basic-dom`.
-- |
-- | `textContent` produces a raw-text JSX node from a string, equivalent
-- | to inlining `{label}` inside an SVG `<text>` element.
module React.FFI.DOM
  ( div_
  , span_
  , button_
  , g_
  , path_
  , text_
  , rect_
  , circle_
  , foreignObject_
  , svg_
  , defs_
  , marker_
  , pattern_
  , polyline_
  , symbol_
  , title_
  , textContent
  , spreadUnder
  , opt
  , scrollResetHandler
  , blurElement
  ) where

import Prelude

import Data.Function.Uncurried (Fn2, runFn2)
import Data.Maybe (Maybe(..))
import Data.Nullable (toNullable)
import Effect (Effect)
import Effect.Uncurried (EffectFn1, mkEffectFn1)
import Foreign (Foreign)
import Foreign.Object (Object)
import React.Basic (JSX)
import React.Basic.Events (EventHandler)
import Unsafe.Coerce (unsafeCoerce)
import Web.DOM.Element (Element)

foreign import div_ :: forall p. Record p -> Array JSX -> JSX
foreign import span_ :: forall p. Record p -> Array JSX -> JSX
foreign import button_ :: forall p. Record p -> Array JSX -> JSX
foreign import g_ :: forall p. Record p -> Array JSX -> JSX
foreign import path_ :: forall p. Record p -> Array JSX -> JSX
foreign import text_ :: forall p. Record p -> Array JSX -> JSX
foreign import rect_ :: forall p. Record p -> Array JSX -> JSX
foreign import circle_ :: forall p. Record p -> Array JSX -> JSX
foreign import foreignObject_ :: forall p. Record p -> Array JSX -> JSX
foreign import svg_ :: forall p. Record p -> Array JSX -> JSX
foreign import defs_ :: forall p. Record p -> Array JSX -> JSX
foreign import marker_ :: forall p. Record p -> Array JSX -> JSX
foreign import pattern_ :: forall p. Record p -> Array JSX -> JSX
foreign import polyline_ :: forall p. Record p -> Array JSX -> JSX
foreign import symbol_ :: forall p. Record p -> Array JSX -> JSX
foreign import title_ :: forall p. Record p -> Array JSX -> JSX

foreign import spreadUnderImpl :: forall p. Fn2 (Object Foreign) (Record p) (Record p)

-- | An element's props with attributes the caller didn't name spread
-- | underneath, as JSX's `<path {...rest} d={path} />` does: a key in both
-- | takes the record's value. The record's type doesn't change, because
-- | `path_` and its siblings take any record.
spreadUnder :: forall p. Maybe (Object Foreign) -> Record p -> Record p
spreadUnder Nothing props = props
spreadUnder (Just attributes) props = runFn2 spreadUnderImpl attributes props

-- | A bare string rendered as a React text child. React accepts strings
-- | directly as JSX children, so the cast is sound.
textContent :: String -> JSX
textContent = unsafeCoerce

-- | Convert a `Maybe a` into something the untyped DOM-prop records can
-- | accept. `Nothing` becomes JS `null` (which React treats the same as
-- | a missing/undefined prop); `Just x` becomes `x`. Used pervasively
-- | by the built-in edge/node/handle components.
opt :: forall a. Maybe a -> a
opt = unsafeCoerce <<< toNullable

-- | Build an `onScroll` handler that snaps the event's `currentTarget`
-- | back to (0, 0) and then runs the user-supplied effect. Used by
-- | `React.Container.ReactFlow` to undo browser tab-focus scrolling on
-- | the outer wrapper.
foreign import scrollResetHandlerImpl
  :: EffectFn1 Unit Unit -> EventHandler

scrollResetHandler :: Effect Unit -> EventHandler
scrollResetHandler cb = scrollResetHandlerImpl (mkEffectFn1 (\_ -> cb))

-- | `element.blur()`, at the widest type the DOM will honestly give it.
-- |
-- | `blur` belongs to `HTMLOrSVGElement`, and PureScript's web bindings model
-- | only the HTML half: `Web.HTML.HTMLElement.blur` wants an `HTMLElement`,
-- | which an `SVGGElement` is not. `React.Component.EdgeWrapper` is the
-- | caller and an edge's element is a `<g>`, so the typed binding cannot
-- | reach it, and coercing the `<g>` to `HTMLElement` to borrow that binding
-- | would be a lie about the element rather than a gap in the bindings.
-- |
-- | `Element` and not an SVG type because there is no SVG type here to name —
-- | which is the whole reason this binding exists — and the name says no more
-- | than the signature can keep.
-- |
-- | `React.Node.Util` deliberately does *not* come through here: a node's
-- | element is a real `<div>`, so it uses `Web.HTML.HTMLElement.blur` and
-- | keeps the typed route where a typed route exists.
foreign import blurElement :: Element -> Effect Unit
