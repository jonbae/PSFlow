# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: timing.spec.mjs >> psflow resets held keyboard modifiers on the blank document between captures
- Location: parity/system/harness/timing.spec.mjs:98:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- application [ref=e4]:
  - generic [ref=e6]:
    - generic:
      - generic:
        - img:
          - group "Edge from Node-1 to Node-2" [ref=e7] [cursor=pointer]:
            - generic [ref=e10]:
              - generic: edge
        - img:
          - group "Edge from Node-1 to Node-3" [ref=e14] [cursor=pointer]:
            - generic [ref=e17]:
              - generic: edge
      - generic:
        - group [active] [ref=e21]: Node-1
        - group [ref=e23]: Node-2
        - group [ref=e25]: Node-3
        - group [ref=e28]: Node-4
        - group [ref=e30]
        - group [ref=e33]: notConnectable
        - group [ref=e34] [cursor=pointer]: notDraggable
        - group [ref=e37]: notSelectable
        - group [ref=e40]: notDeletable
  - link "React Flow attribution" [ref=e44] [cursor=pointer]:
    - /url: https://reactflow.dev
    - text: React Flow
```

# Test source

```ts
  8   | import { runScenario } from './scenario.mjs';
  9   | import { createPagePort } from './port.mjs';
  10  | 
  11  | const {fixtures, components} = routeSpace(process.cwd());
  12  | const corpus = buildCorpus(fixtures, components);
  13  | const rules = JSON.parse(readFileSync('parity/system/normalization.json')).rules;
  14  | const baseline = JSON.parse(readFileSync('xyflow/packages/react/package.json')).version;
  15  | const cases = [
  16  |   ['drag-node-autopan', 'onNodeDragStop'],
  17  |   ['drag-node-reports-changes', 'onNodeDragStop'],
  18  |   ['wheel-zoom-from-identity-viewport', 'onMoveEnd'],
  19  |   ['ctrl-wheel-pinches-with-panonscroll', 'onMoveEnd'],
  20  |   ['pan-after-controlled-viewport-change', 'onMoveEnd'],
  21  |   ['arrow-key-selected-node', 'onNodesChange'],
  22  | ];
  23  | 
  24  | for (const side of ['upstream', 'psflow']) {
  25  |   for (const [id, witness] of cases) {
  26  |     test(`${side} reproduces the complete ${id} trace across independent captures`, async ({page}) => {
  27  |       test.skip(!existsSync(`parity/driver/dist/${side}.js`), 'bundle not built');
  28  |       const scenario = corpus.find(s => s.id === id);
  29  |       const traces = [];
  30  |       for (const capture of [1, 2, 3]) {
  31  |         const trace = await runScenario(page, scenario, {side, capture, baseline});
  32  |         expect(trace.sections.callbacks.some(c => c.name === witness)).toBe(true);
  33  |         traces.push(trace);
  34  |       }
  35  |       for (const trace of traces.slice(1)) {
  36  |         expect(checkSelfConsistency(traces[0], trace, {rules}).differences).toEqual([]);
  37  |       }
  38  |     });
  39  |   }
  40  | }
  41  | 
  42  | test('wheel dispatch completes its finite timeout chain before returning', async ({page}) => {
  43  |   const port = createPagePort(page);
  44  |   await port.prepareMount();
  45  |   await page.setContent(`<div style="width:500px;height:500px"></div><script>
  46  |     window.receipts = [];
  47  |     document.addEventListener('wheel', () => {
  48  |       receipts.push('wheel');
  49  |       setTimeout(() => {
  50  |         receipts.push('idle');
  51  |         setTimeout(() => receipts.push('end'), 150);
  52  |       }, 150);
  53  |     });
  54  |   </script>`);
  55  |   await port.finishMount();
  56  |   await port.wheel({x:100, y:100}, {deltaX:0, deltaY:-100});
  57  |   // No retry: returning before the chain completes is the defect.
  58  |   expect(await page.evaluate(() => window.receipts)).toEqual(['wheel', 'idle', 'end']);
  59  | });
  60  | 
  61  | test('a navigation holds zero-delay timers until application frames advance', async ({page}) => {
  62  |   // Real navigation is load-bearing: setContent does not replay clock logs.
  63  |   await page.route('**/clock-probe.html', route => route.fulfill({
  64  |     contentType:'text/html',body:`<div id="target" style="width:10px;height:10px"></div>
  65  |       <script src="/parity/driver/dist/clock-probe.js"></script>`,
  66  |   }));
  67  |   await page.route('**/parity/driver/dist/clock-probe.js', route => route.fulfill({
  68  |     contentType:'application/javascript',body:`window.receipts=[];
  69  |       const observer=new ResizeObserver(()=>{receipts.push('resize');observer.disconnect();});
  70  |       observer.observe(document.querySelector('#target'));
  71  |       setTimeout(()=>receipts.push('timer'),0);`,
  72  |   }));
  73  |   const port=createPagePort(page);
  74  |   const advance=await port.prepareMount();
  75  |   await page.goto('/clock-probe.html');
  76  |   for(let frame=0;frame<8;frame++) await port.tick();
  77  |   expect(await page.evaluate(()=>window.receipts)).toEqual(['resize']);
  78  |   await advance();
  79  |   await port.tick();
  80  |   expect(await page.evaluate(()=>window.receipts)).toEqual(['resize','timer']);
  81  |   await port.finishMount();
  82  | });
  83  | 
  84  | for(const side of ['upstream','psflow']) {
  85  |   test(`${side} completes an animated imperative call with time held between actions`,async({page})=>{
  86  |     const {defineScenario}=await import('./scenario.mjs');
  87  |     const {routeOf}=await import('../corpus/routes.mjs');
  88  |     const scenario=defineScenario({id:'live--animated-viewport',route:routeOf('./flow/chrome-defaults.ts'),
  89  |       run:async a=>{await a.call('setViewport',[{x:25,y:10,zoom:1.2},{duration:96}]);}});
  90  |     const trace=await runScenario(page,scenario,{side,capture:1,baseline});
  91  |     expect(trace.sections.api.calls[0].result).toBe(true);
  92  |     expect(trace.sections.callbacks.some(c=>c.name==='onMoveEnd')).toBe(true);
  93  |     expect(await page.locator('.react-flow__viewport').getAttribute('style')).toContain('translate(25px, 10px) scale(1.2)');
  94  |   });
  95  | }
  96  | 
  97  | for(const side of ['upstream','psflow']) {
  98  |   test(`${side} resets held keyboard modifiers on the blank document between captures`,async({page})=>{
  99  |     const {defineScenario}=await import('./scenario.mjs');
  100 |     const held=defineScenario({id:'live--held-shift',route:'/tests/generic/nodes/general',
  101 |       run:async a=>{await a.key('Shift',{action:'down'});}});
  102 |     const click=defineScenario({id:'live--plain-click',route:'/tests/generic/nodes/general',
  103 |       run:async a=>{await a.click('.react-flow__node[data-id="Node-1"]');}});
  104 |     await runScenario(page,held,{side,capture:1,baseline});
  105 |     const trace=await runScenario(page,click,{side,capture:2,baseline});
  106 |     const events=trace.sections.callbacks.flatMap(c=>c.args).filter(a=>a&&Object.hasOwn(a,'shiftKey'));
  107 |     expect(events.length).toBeGreaterThan(0);
> 108 |     expect(events.every(e=>!e.shiftKey&&!e.altKey&&!e.ctrlKey&&!e.metaKey)).toBe(true);
      |                                                                             ^ Error: expect(received).toBe(expected) // Object.is equality
  109 |   });
  110 | }
  111 | 
```