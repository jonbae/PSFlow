# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: timing.spec.mjs >> psflow reproduces the complete drag-node-reports-changes trace across independent captures
- Location: parity/system/harness/timing.spec.mjs:26:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: cdpSession.detach: Target page, context or browser has been closed
```

# Page snapshot

```yaml
- application [ref=e4]:
  - generic [ref=e6]:
    - generic:
      - generic:
        - img:
          - group "Edge from n1 to n2" [ref=e7] [cursor=pointer]
      - generic:
        - group [active] [ref=e12]: n1
        - group [ref=e15]: n2
  - generic "Control Panel" [ref=e18]:
    - button "Zoom In" [ref=e19] [cursor=pointer]:
      - img [ref=e20]
    - button "Zoom Out" [ref=e22] [cursor=pointer]:
      - img [ref=e23]
    - button "Fit View" [ref=e25] [cursor=pointer]:
      - img [ref=e26]
    - button "Toggle Interactivity" [ref=e28] [cursor=pointer]:
      - img [ref=e29]
  - img "Mini Map" [ref=e32]
  - img
  - link "React Flow attribution" [ref=e36] [cursor=pointer]:
    - /url: https://reactflow.dev
    - text: React Flow
```

# Test source

```ts
  1   | import { installTimerObserver } from "./platform-timers.mjs";
  2   | // The page port — the only file in the harness that knows what a browser is.
  3   | //
  4   | // Everything above it (the vocabulary, the gestures, the driving log) is plain
  5   | // composition over this interface, which is why all of it is tested without a
  6   | // browser against `fake-port.mjs`. Keep the two in step: `port.test.mjs` checks
  7   | // they still answer the same method names, so a double that drifts is caught
  8   | // by a node test rather than by a browser run failing strangely.
  9   | //
  10  | // The port resolves and dispatches. It decides nothing: what to aim at, what to
  11  | // record, and whether a miss is a failure all belong upstairs.
  12  | 
  13  | import { CALL_LOG } from "./call-log.mjs";
  14  | import { domSection } from "./dom.mjs";
  15  | import { OBSERVATIONS } from "../../driver/observations.mjs";
  16  | 
  17  | const CDP_TOUCH = { touchStart: 1, touchMove: 1, touchEnd: 1, touchCancel: 1 };
  18  | const clockContexts = new WeakSet();
  19  | const timerPages = new WeakSet();
  20  | 
  21  | /**
  22  |  * `resolveTimeout` bounds how long a selector is given before it counts as
  23  |  * unresolved. It exists because an element that appears a moment after the
  24  |  * action asks for it is not a divergence, and an element that never appears
  25  |  * must not cost the whole run: past this, the miss is **recorded and skipped**
  26  |  * by the vocabulary above, never thrown. Left alone, that miss would surface as
  27  |  * a Playwright timeout, which reads as a flake.
  28  |  */
  29  | export const createPagePort = (page, { resolveTimeout = 1_000 } = {}) => {
  30  |   // Where the mouse actually is, so that a press does not emit a redundant
  31  |   // mousemove first. An explicit `pointerMove` always dispatches — a scenario
  32  |   // asking for a move is asking for the event, even a zero-length one.
  33  |   let at = { x: 0, y: 0 };
  34  | 
  35  |   // `Input.dispatchTouchEvent` reaches a page reporting no touch support and is
  36  |   // ignored there, so emulation has to be on — and it has to be on **before the
  37  |   // document loads**. Turning it on afterwards leaves `ontouchstart in window`
  38  |   // false and every dispatched touch inert, which was measured rather than
  39  |   // assumed: the same touch drag that moves a node with emulation enabled
  40  |   // before `goto` moves nothing when it is enabled after.
  41  |   //
  42  |   // So it is a scenario's declared capability, not something a `touch` call can
  43  |   // turn on for itself. Enabling it everywhere would be symmetric across the
  44  |   // sides and therefore sound, but it would quietly narrow the whole net to a
  45  |   // touch-capable browser — every scenario taking xyflow's touch code paths
  46  |   // because two scenarios needed them.
  47  |   //
  48  |   // The CDP session is what the corpus ticket bought by specifying
  49  |   // `Input.dispatchTouchEvent`: no new browser target, no second Playwright
  50  |   // project, no config change.
  51  |   let cdp = null;
  52  |   let frameSession = null;
  53  |   let mountPhase = null;
  54  |   let clockPrepared = false;
  55  | 
  56  |   // Clock emulation controls JS timers, not native layout/ResizeObserver work.
  57  |   // This isolated world retains the browser's animation-frame clock while the
  58  |   // application's clock is paused. It reads no application data and mutates no
  59  |   // DOM. Both sides use the same native frame and virtual timer protocol.
  60  |   const nativeFrame = async () => {
  61  |     const persistent = Boolean(mountPhase);
  62  |     const session = persistent
  63  |       ? (frameSession ??= await page.context().newCDPSession(page))
  64  |       : await page.context().newCDPSession(page);
  65  |     try {
  66  |       const { frameTree } = await session.send("Page.getFrameTree");
  67  |       const { executionContextId } = await session.send("Page.createIsolatedWorld", {
  68  |         frameId: frameTree.frame.id,
  69  |         worldName: "psflow-native-frame",
  70  |       });
  71  |       const result = await session.send("Runtime.evaluate", {
  72  |         contextId: executionContextId,
  73  |         expression: "new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(() => setTimeout(resolve, 0))))",
  74  |         awaitPromise: true,
  75  |         returnByValue: true,
  76  |       });
  77  |       if (result.exceptionDetails) throw new Error("native frame failed");
  78  |     } finally {
> 79  |       if (!persistent) await session.detach();
      |                                      ^ Error: cdpSession.detach: Target page, context or browser has been closed
  80  |     }
  81  |   };
  82  | 
  83  |   const moveTo = async ({ x, y }) => {
  84  |     await page.mouse.move(x, y);
  85  |     at = { x, y };
  86  |     if (clockPrepared && !mountPhase) await tick();
  87  |   };
  88  | 
  89  |   const tick = async () => {
  90  |     if (mountPhase) {
  91  |       await nativeFrame();
  92  |       if (mountPhase === "timers") await page.clock.runFor(32);
  93  |       return;
  94  |     }
  95  |     if (clockPrepared) {
  96  |       await nativeFrame();
  97  |       for (let frame = 0; frame < 2; frame++) {
  98  |         const now = await page.evaluate(() => performance.now());
  99  |         await page.clock.runFor(16 - (now % 16));
  100 |         await nativeFrame();
  101 |       }
  102 |       return;
  103 |     }
  104 |     await page.evaluate(
  105 |       () =>
  106 |         new Promise((resolve) => {
  107 |           requestAnimationFrame(() => requestAnimationFrame(() => setTimeout(resolve, 0)));
  108 |         })
  109 |     );
  110 |   };
  111 | 
  112 |   return {
  113 |     /**
  114 |      * Called on the blank document, before application clock use. Timers stay
  115 |      * paused while the caller observes native layout; the returned function
  116 |      * starts two-frame timer steps after that layout has settled.
  117 |      */
  118 |     async prepareMount() {
  119 |       const context = page.context();
  120 |       if (!clockContexts.has(context)) {
  121 |         await page.clock.install({ time: Date.UTC(2026, 0, 1) });
  122 |         clockContexts.add(context);
  123 |       }
  124 |       await page.clock.pauseAt(await page.evaluate(() => Date.now()) + 1000);
  125 |       if (!timerPages.has(page)) {
  126 |         await page.addInitScript(installTimerObserver);
  127 |         timerPages.add(page);
  128 |       }
  129 |       await page.evaluate(installTimerObserver);
  130 |       // A replayed pause on navigation leaves Playwright's initial native
  131 |       // zero-delay dispatcher alive. Cancel it through the public clock API
  132 |       // before any library code executes, identically for either bundle.
  133 |       await page.route(/\.m?js(?:\?|$)/, async route => {
  134 |         await page.clock.pauseAt(await page.evaluate(() => Date.now()));
  135 |         await route.continue();
  136 |       }, { times: 1 });
  137 |       clockPrepared = true;
  138 |       mountPhase = "layout";
  139 |       return async () => { mountPhase = "timers"; };
  140 |     },
  141 | 
  142 |     /** Switch to paced actions; held gestures keep receiving virtual frames. */
  143 |     async finishMount() {
  144 |       // Keep time held between input commands. tick advances it explicitly.
  145 |       mountPhase = null;
  146 |       if (frameSession) {
  147 |         await frameSession.detach();
  148 |         frameSession = null;
  149 |       }
  150 |     },
  151 | 
  152 |     /**
  153 |      * Turns on touch emulation, and must be called **before the page is
  154 |      * navigated**. `runScenario` does it for a scenario declaring `touch: true`.
  155 |      */
  156 |     async enableTouch() {
  157 |       cdp ??= await page.context().newCDPSession(page);
  158 |       await cdp.send("Emulation.setTouchEmulationEnabled", { enabled: true, maxTouchPoints: 10 });
  159 |     },
  160 | 
  161 |     /**
  162 |      * The box, or null when the selector does not resolve. Never throws.
  163 |      * `timeout` overrides the default for the one case that is not an action —
  164 |      * the mount, which waits on a bundle downloading and a flow rendering.
  165 |      */
  166 |     async box(selector, { timeout = resolveTimeout } = {}) {
  167 |       let pending;
  168 |       try {
  169 |         // `.first()`: a selector matching several elements resolves to one, the
  170 |         // same one on both sides, rather than being a strict-mode error that
  171 |         // would read as an infrastructure fault instead of a target choice.
  172 |         pending = page.locator(selector).first().boundingBox({ timeout });
  173 |       } catch {
  174 |         // Not attached, not visible, or gone before it could be measured. All
  175 |         // three are "did not resolve", and the difference between them is not
  176 |         // something the driving log claims to record.
  177 |         return null;
  178 |       }
  179 |       let done = false;
```