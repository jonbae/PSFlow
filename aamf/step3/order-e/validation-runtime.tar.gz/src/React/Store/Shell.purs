-- | `Effect`-typed shell around the pure reducer. Owns the single
-- | `Ref ReactFlowState`, the subscriber list, the middleware-key
-- | counter, and the `Effect_` interpreter that turns reducer-emitted
-- | descriptors into real side effects.
-- |
-- | Mirrors the runtime half of Zustand's `createStore` while keeping
-- | the public-facing contract (`getState`, `setState`, `subscribe`,
-- | `dispatch`) byte-compatible with upstream's `StoreApi`.
module React.Store.Shell
  ( Store
  , StoreApi
  , Subscribe(..)
  , createStore
  ) where

import Prelude

import Data.Array (filter) as Array
import Data.Foldable (for_, traverse_)
import Data.Maybe (Maybe(..), fromMaybe)
import Effect (Effect)
import Effect.Aff (launchAff_)
import Effect.Aff.AVar as AffAVar
import Effect.Ref as Ref
import React.Store.Action (Action(..), Effect_(..))
import React.Store.InitialState (InitialStateOptions, initialState)
import React.Store.Reduce (reduce)
import React.Types.Store (MiddlewareKey(..), ReactFlowState)
import System.Constants (errorMessage)
import System.Utils.Graph (fitViewport)
import System.Utils.Store (updateNodeInternals)
import Unsafe.Reference (unsafeRefEq)
import Web.HTML.HTMLDivElement (toHTMLElement)

-- | One subscriber. Each `subscribe` call captures its selector and
-- | `Eq` instance into a closure of type
-- | `ReactFlowState -> ReactFlowState -> Effect Unit`. The closure
-- | re-runs the selector on the prev/next state, compares, and fires
-- | the callback if the projection changed.
type Subscriber n e =
  { onUpdate :: ReactFlowState n e -> ReactFlowState n e -> Effect Unit
  , key :: Int
  }

-- | Rank-N polymorphic `subscribe` wrapped in a newtype so it can live
-- | inside the `Store` record (PS records don't permit polymorphic
-- | fields with class constraints).
newtype Subscribe n e = Subscribe
  ( forall a
     . Eq a
    => (ReactFlowState n e -> a)
    -> (a -> Effect Unit)
    -> Effect (Effect Unit)
  )

-- | The Zustand-compatible API surface. Consumers (hooks, the
-- | provider) see only this record — they never touch the internal
-- | Refs directly.
type Store n e =
  { getState :: Effect (ReactFlowState n e)
  , setState :: (ReactFlowState n e -> ReactFlowState n e) -> Effect Unit
  , subscribe :: Subscribe n e
  -- | Zustand's own `subscribe(listener)`: the listener runs after every
  -- | dispatch that replaced the state, with no selector between them.
  -- | `React.Hook.Store.useStore` hands it to React's
  -- | `useSyncExternalStore`, which reads the slice itself. A selector here
  -- | would be the one captured when the subscription was made, and a
  -- | consumer's selector can change from render to render.
  , subscribeAll :: Effect Unit -> Effect (Effect Unit)
  , dispatch :: Action n e -> Effect Unit
  , freshMiddlewareKey :: Effect MiddlewareKey
  }

type StoreApi n e = Store n e

createStore :: forall n e. InitialStateOptions n e -> Effect (Store n e)
createStore opts = do
  stateRef <- Ref.new (initialState opts)
  subsRef <- Ref.new ([] :: Array (Subscriber n e))
  nextSubKeyRef <- Ref.new 0
  middlewareKeyRef <- Ref.new 0

  let
    interpretEffect :: (Action n e -> Effect Unit) -> Effect_ n e -> Effect Unit
    interpretEffect dispatch_ eff = case eff of
      FireOnNodesChange cs -> do
        s <- Ref.read stateRef
        case s.onNodesChange of
          Just cb -> cb cs
          Nothing -> pure unit
      FireOnEdgesChange cs -> do
        s <- Ref.read stateRef
        case s.onEdgesChange of
          Just cb -> cb cs
          Nothing -> pure unit
      FireOnSelectionChange params -> do
        s <- Ref.read stateRef
        for_ s.onSelectionChangeHandlers \cb -> cb params
      FireOnConnect c -> do
        s <- Ref.read stateRef
        case s.onConnect of
          Just cb -> cb c
          Nothing -> pure unit
      -- onConnectStart/End fire with a DOM event; that event isn't
      -- available at the reducer level. The hook layer (ticket 031)
      -- raises these callbacks directly with the event in hand.
      FireOnConnectStart _ -> pure unit
      FireOnConnectEnd _ -> pure unit
      RunDomUpdateNodeInternals updates dopts -> do
        s <- Ref.read stateRef
        r <- updateNodeInternals updates s.nodeLookup s.parentLookup
          (map toHTMLElement s.domNode)
          s.nodeOrigin
          s.nodeExtent
          s.zIndexMode
        dispatch_
          ( MergeNodeInternalsResult
              { nodeLookup: r.nodeLookup
              , parentLookup: r.parentLookup
              , changes: r.changes
              , updatedInternals: r.updatedInternals
              , triggerFitView: dopts.triggerFitView
              }
          )
      RunSetCenter x y opts -> do
        -- The store's setCenter is also used by NodeWrapper's focus path.
        -- Reading and invoking panZoom happens before its async continuation,
        -- just as in the upstream store action.
        s <- Ref.read stateRef
        for_ s.panZoom \pz -> do
          let zoom = fromMaybe s.maxZoom opts.zoom
          launchAff_ $ void $ pz.setViewport
            { x: s.width / 2.0 - x * zoom
            , y: s.height / 2.0 - y * zoom
            , zoom
            }
            (Just { duration: opts.duration, ease: opts.ease, interpolate: opts.interpolate })
      RunSetScaleExtent mn mx -> do
        -- No instance yet means the flow has not mounted its pane, and
        -- `createXYPanZoom` seeds the extent from the same state when it
        -- does. That is upstream's `panZoom?.` optional call.
        s <- Ref.read stateRef
        case s.panZoom of
          Just pz -> pz.setScaleExtent mn mx
          Nothing -> pure unit
      RunSetTranslateExtent ext -> do
        s <- Ref.read stateRef
        case s.panZoom of
          Just pz -> pz.setTranslateExtent ext
          Nothing -> pure unit
      ResolveFitView b -> do
        -- Mirror the React store's `resolveFitView`: apply the fitted
        -- viewport via `panZoom.setViewport` (which fires d3's zoom event,
        -- so `ZoomPane.onTransformChange` writes the new `state.transform`),
        -- then resolve the awaiting `fitView()` AVar. No panZoom yet → just
        -- resolve, matching upstream's early return.
        s <- Ref.read stateRef
        let
          resolveAVar = case s.fitViewResolver of
            Just avar -> AffAVar.put b avar
            Nothing -> pure unit
        case s.panZoom of
          Nothing -> launchAff_ resolveAVar
          Just pz -> launchAff_ do
            _ <- fitViewport
              { nodes: s.nodeLookup
              , width: s.width
              , height: s.height
              , panZoom: pz
              , minZoom: s.minZoom
              , maxZoom: s.maxZoom
              }
              s.fitViewOptions
            resolveAVar
      LogError code -> do
        s <- Ref.read stateRef
        case s.onError of
          Just cb -> cb (errorCodeName code) (errorMessage code)
          Nothing -> pure unit

    notifySubscribers prev next = do
      subs <- Ref.read subsRef
      for_ subs \sub -> sub.onUpdate prev next

  let
    dispatch :: Action n e -> Effect Unit
    dispatch action = do
      prev <- Ref.read stateRef
      let res = reduce prev action
      Ref.write res.state stateRef
      notifySubscribers prev res.state
      traverse_ (interpretEffect dispatch) res.effects

    setState f = dispatch (PatchState f)
    getState = Ref.read stateRef

    subscribe = Subscribe \selector cb -> do
      key <- Ref.modify (_ + 1) nextSubKeyRef
      let
        onUpdate prev next =
          let
            prevV = selector prev
            nextV = selector next
          in
            if prevV == nextV then pure unit
            else cb nextV
      Ref.modify_ (\xs -> xs <> [ { onUpdate, key } ]) subsRef
      -- No fire on subscribe. Zustand's `subscribe` does not call back with
      -- the current value; only `subscribeWithSelector` under an explicit
      -- `fireImmediately` does, and upstream never asks for it. The one
      -- caller, `React.Hook.Store.useStore`, seeds its own `useState` from
      -- `store.getState` before this runs, so firing here was a second
      -- `setValue` with a value the consumer already held.
      --
      -- It was also nondeterministic. Every consumer's subscription lands in
      -- its own `useEffect`, so the extra `setValue`s arrived in mount order
      -- and React batched them differently run to run — which is what put 52
      -- of 94 scenarios into `callbacks | ordered differently` against their
      -- own second capture. See "Diagnose why ps-flow does not reproduce
      -- itself on 52 of 94 scenarios" (#94).
      pure (Ref.modify_ (Array.filter (\sub -> sub.key /= key)) subsRef)

    -- Zustand notifies when `!Object.is(nextState, state)`, and so does
    -- this: a dispatch whose reducer handed the same state back is not a
    -- change. Listeners share the selector subscribers' list, so the two
    -- kinds run in the order they subscribed, as zustand's one `Set` does.
    subscribeAll listener = do
      key <- Ref.modify (_ + 1) nextSubKeyRef
      let
        onUpdate prev next = unless (unsafeRefEq prev next) listener
      Ref.modify_ (\xs -> xs <> [ { onUpdate, key } ]) subsRef
      pure (Ref.modify_ (Array.filter (\sub -> sub.key /= key)) subsRef)

    freshMiddlewareKey = do
      n <- Ref.modify (_ + 1) middlewareKeyRef
      pure (MiddlewareKey n)

  pure
    { getState
    , setState
    , subscribe
    , subscribeAll
    , dispatch
    , freshMiddlewareKey
    }

-- | The first segment of `https://reactflow.dev/error#NNN` — the
-- | numeric tag. Used to satisfy the `OnError` signature
-- | `String -> String -> Effect Unit` (id, message).
errorCodeName :: forall a. a -> String
errorCodeName _ =
  -- Error tags carry richer payloads (some have String/HandleType
  -- arguments) so we don't pattern-match here; the message itself is
  -- the primary surface. The shell uses an empty id; the hook layer
  -- can override if a more granular tag is needed.
  ""
