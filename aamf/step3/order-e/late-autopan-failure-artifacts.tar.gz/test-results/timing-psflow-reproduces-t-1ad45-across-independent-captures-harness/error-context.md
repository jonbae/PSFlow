# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: timing.spec.mjs >> psflow reproduces the complete drag-node-autopan trace across independent captures
- Location: parity/system/harness/timing.spec.mjs:26:5

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 26

- Array []
+ Array [
+   Object {
+     "kind": "changed",
+     "left": true,
+     "path": Array [
+       "callbacks",
+       61,
+       "args",
+       0,
+       "shiftKey",
+     ],
+     "right": false,
+   },
+   Object {
+     "kind": "changed",
+     "left": true,
+     "path": Array [
+       "callbacks",
+       65,
+       "args",
+       0,
+       "shiftKey",
+     ],
+     "right": false,
+   },
+ ]
```

# Page snapshot

```yaml
- application [ref=e4]:
  - generic [ref=e6]:
    - generic:
      - generic:
        - img:
          - group "Edge from Node-1 to Node-2" [ref=e7] [cursor=pointer]
        - img:
          - group "Edge from Node-1 to Node-3" [ref=e12] [cursor=pointer]
      - generic:
        - group [active] [ref=e17]: Node-1
        - group [ref=e19]: Node-2
        - group [ref=e22]: Node-3
  - link "React Flow attribution" [ref=e26] [cursor=pointer]:
    - /url: https://reactflow.dev
    - text: React Flow
```

# Test source

```ts
  1  | // Browser-port regressions: native input/rendering and controlled app time must
  2  | // produce the complete original trace, including every callback and its order.
  3  | import { test, expect } from '@playwright/test';
  4  | import { readFileSync, existsSync } from 'node:fs';
  5  | import { routeSpace } from '../../driver/registry.mjs';
  6  | import { buildCorpus } from '../corpus/index.mjs';
  7  | import { checkSelfConsistency } from '../compare/consistency.mjs';
  8  | import { runScenario } from './scenario.mjs';
  9  | import { createPagePort } from './port.mjs';
  10 | 
  11 | const {fixtures, components} = routeSpace(process.cwd());
  12 | const corpus = buildCorpus(fixtures, components);
  13 | const rules = JSON.parse(readFileSync('parity/system/normalization.json')).rules;
  14 | const baseline = JSON.parse(readFileSync('xyflow/packages/react/package.json')).version;
  15 | const cases = [
  16 |   ['drag-node-autopan', 'onNodeDragStop'],
  17 |   ['drag-node-reports-changes', 'onNodeDragStop'],
  18 |   ['wheel-zoom-from-identity-viewport', 'onMoveEnd'],
  19 |   ['ctrl-wheel-pinches-with-panonscroll', 'onMoveEnd'],
  20 |   ['pan-after-controlled-viewport-change', 'onMoveEnd'],
  21 |   ['arrow-key-selected-node', 'onNodesChange'],
  22 | ];
  23 | 
  24 | for (const side of ['upstream', 'psflow']) {
  25 |   for (const [id, witness] of cases) {
  26 |     test(`${side} reproduces the complete ${id} trace across independent captures`, async ({page}) => {
  27 |       test.skip(!existsSync(`parity/driver/dist/${side}.js`), 'bundle not built');
  28 |       const scenario = corpus.find(s => s.id === id);
  29 |       const traces = [];
  30 |       for (const capture of [1, 2, 3]) {
  31 |         const trace = await runScenario(page, scenario, {side, capture, baseline});
  32 |         expect(trace.sections.callbacks.some(c => c.name === witness)).toBe(true);
  33 |         traces.push(trace);
  34 |       }
  35 |       for (const trace of traces.slice(1)) {
> 36 |         expect(checkSelfConsistency(traces[0], trace, {rules}).differences).toEqual([]);
     |                                                                             ^ Error: expect(received).toEqual(expected) // deep equality
  37 |       }
  38 |     });
  39 |   }
  40 | }
  41 | 
  42 | test('wheel dispatch completes its finite timeout chain before returning', async ({page}) => {
  43 |   const port = createPagePort(page);
  44 |   await port.prepareMount();
  45 |   await page.setContent(`<div style="width:500px;height:500px"></div><script>
  46 |     window.receipts = [];
  47 |     document.addEventListener('wheel', () => {
  48 |       receipts.push('wheel');
  49 |       setTimeout(() => {
  50 |         receipts.push('idle');
  51 |         setTimeout(() => receipts.push('end'), 150);
  52 |       }, 150);
  53 |     });
  54 |   </script>`);
  55 |   await port.finishMount();
  56 |   await port.wheel({x:100, y:100}, {deltaX:0, deltaY:-100});
  57 |   // No retry: returning before the chain completes is the defect.
  58 |   expect(await page.evaluate(() => window.receipts)).toEqual(['wheel', 'idle', 'end']);
  59 | });
  60 | 
  61 | test('a navigation holds zero-delay timers until application frames advance', async ({page}) => {
  62 |   // Real navigation is load-bearing: setContent does not replay clock logs.
  63 |   await page.route('**/clock-probe.html', route => route.fulfill({
  64 |     contentType:'text/html',body:`<div id="target" style="width:10px;height:10px"></div>
  65 |       <script src="/parity/driver/dist/clock-probe.js"></script>`,
  66 |   }));
  67 |   await page.route('**/parity/driver/dist/clock-probe.js', route => route.fulfill({
  68 |     contentType:'application/javascript',body:`window.receipts=[];
  69 |       const observer=new ResizeObserver(()=>{receipts.push('resize');observer.disconnect();});
  70 |       observer.observe(document.querySelector('#target'));
  71 |       setTimeout(()=>receipts.push('timer'),0);`,
  72 |   }));
  73 |   const port=createPagePort(page);
  74 |   const advance=await port.prepareMount();
  75 |   await page.goto('/clock-probe.html');
  76 |   for(let frame=0;frame<8;frame++) await port.tick();
  77 |   expect(await page.evaluate(()=>window.receipts)).toEqual(['resize']);
  78 |   await advance();
  79 |   await port.tick();
  80 |   expect(await page.evaluate(()=>window.receipts)).toEqual(['resize','timer']);
  81 |   await port.finishMount();
  82 | });
  83 | 
  84 | for(const side of ['upstream','psflow']) {
  85 |   test(`${side} completes an animated imperative call with time held between actions`,async({page})=>{
  86 |     const {defineScenario}=await import('./scenario.mjs');
  87 |     const {routeOf}=await import('../corpus/routes.mjs');
  88 |     const scenario=defineScenario({id:'live--animated-viewport',route:routeOf('./flow/chrome-defaults.ts'),
  89 |       run:async a=>{await a.call('setViewport',[{x:25,y:10,zoom:1.2},{duration:96}]);}});
  90 |     const trace=await runScenario(page,scenario,{side,capture:1,baseline});
  91 |     expect(trace.sections.api.calls[0].result).toBe(true);
  92 |     expect(trace.sections.callbacks.some(c=>c.name==='onMoveEnd')).toBe(true);
  93 |     expect(await page.locator('.react-flow__viewport').getAttribute('style')).toContain('translate(25px, 10px) scale(1.2)');
  94 |   });
  95 | }
  96 | 
```