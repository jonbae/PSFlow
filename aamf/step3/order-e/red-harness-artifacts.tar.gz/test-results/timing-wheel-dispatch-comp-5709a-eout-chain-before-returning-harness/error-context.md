# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: timing.spec.mjs >> wheel dispatch completes its finite timeout chain before returning
- Location: parity/system/harness/timing.spec.mjs:42:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 5
+ Received  + 1

- Array [
-   "wheel",
-   "idle",
-   "end",
- ]
+ Array []
```

# Test source

```ts
  1  | // Browser-port regressions: native input/rendering and controlled app time must
  2  | // produce the complete original trace, including every callback and its order.
  3  | import { test, expect } from '@playwright/test';
  4  | import { readFileSync, existsSync } from 'node:fs';
  5  | import { routeSpace } from '../../driver/registry.mjs';
  6  | import { buildCorpus } from '../corpus/index.mjs';
  7  | import { checkSelfConsistency } from '../compare/consistency.mjs';
  8  | import { runScenario } from './scenario.mjs';
  9  | import { createPagePort } from './port.mjs';
  10 | 
  11 | const {fixtures, components} = routeSpace(process.cwd());
  12 | const corpus = buildCorpus(fixtures, components);
  13 | const rules = JSON.parse(readFileSync('parity/system/normalization.json')).rules;
  14 | const baseline = JSON.parse(readFileSync('xyflow/packages/react/package.json')).version;
  15 | const cases = [
  16 |   ['drag-node-autopan', 'onNodeDragStop'],
  17 |   ['drag-node-reports-changes', 'onNodeDragStop'],
  18 |   ['wheel-zoom-from-identity-viewport', 'onMoveEnd'],
  19 |   ['ctrl-wheel-pinches-with-panonscroll', 'onMoveEnd'],
  20 |   ['pan-after-controlled-viewport-change', 'onMoveEnd'],
  21 |   ['arrow-key-selected-node', 'onNodesChange'],
  22 | ];
  23 | 
  24 | for (const side of ['upstream', 'psflow']) {
  25 |   for (const [id, witness] of cases) {
  26 |     test(`${side} reproduces the complete ${id} trace across independent captures`, async ({page}) => {
  27 |       test.skip(!existsSync(`parity/driver/dist/${side}.js`), 'bundle not built');
  28 |       const scenario = corpus.find(s => s.id === id);
  29 |       const traces = [];
  30 |       for (const capture of [1, 2, 3]) {
  31 |         const trace = await runScenario(page, scenario, {side, capture, baseline});
  32 |         expect(trace.sections.callbacks.some(c => c.name === witness)).toBe(true);
  33 |         traces.push(trace);
  34 |       }
  35 |       for (const trace of traces.slice(1)) {
  36 |         expect(checkSelfConsistency(traces[0], trace, {rules}).differences).toEqual([]);
  37 |       }
  38 |     });
  39 |   }
  40 | }
  41 | 
  42 | test('wheel dispatch completes its finite timeout chain before returning', async ({page}) => {
  43 |   const port = createPagePort(page);
  44 |   await port.prepareMount();
  45 |   await page.setContent(`<div style="width:500px;height:500px"></div><script>
  46 |     window.receipts = [];
  47 |     document.addEventListener('wheel', () => {
  48 |       receipts.push('wheel');
  49 |       setTimeout(() => {
  50 |         receipts.push('idle');
  51 |         setTimeout(() => receipts.push('end'), 150);
  52 |       }, 150);
  53 |     });
  54 |   </script>`);
  55 |   await port.finishMount();
  56 |   await port.wheel({x:100, y:100}, {deltaX:0, deltaY:-100});
  57 |   // No retry: returning before the chain completes is the defect.
> 58 |   expect(await page.evaluate(() => window.receipts)).toEqual(['wheel', 'idle', 'end']);
     |                                                      ^ Error: expect(received).toEqual(expected) // deep equality
  59 | });
  60 | 
```