# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: timing.spec.mjs >> psflow reproduces the complete drag-node-autopan trace across independent captures
- Location: parity/system/harness/timing.spec.mjs:26:5

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -   1
+ Received  + 594

- Array []
+ Array [
+   Object {
+     "kind": "left-only",
+     "left": Object {
+       "args": Array [
+         Object {
+           "@class": "SyntheticBaseEvent",
+           "_reactName": "onMouseLeave",
+           "_targetInst": Object {
+             "@ref": "React fiber",
+           },
+           "altKey": false,
+           "bubbles": true,
+           "button": 0,
+           "buttons": 1,
+           "cancelable": true,
+           "clientX": 5,
+           "clientY": 6,
+           "ctrlKey": false,
+           "currentTarget": Object {
+             "@ref": "DIV",
+           },
+           "defaultPrevented": false,
+           "detail": 0,
+           "eventPhase": 3,
+           "getModifierState": Object {
+             "@ref": "function",
+           },
+           "isDefaultPrevented": Object {
+             "@ref": "function",
+           },
+           "isPropagationStopped": Object {
+             "@ref": "function",
+           },
+           "isTrusted": true,
+           "metaKey": false,
+           "movementX": 0,
+           "movementY": 0,
+           "nativeEvent": Object {
+             "@class": "MouseEvent",
+             "isTrusted": true,
+           },
+           "pageX": 5,
+           "pageY": 6,
+           "relatedTarget": Object {
+             "@ref": "DIV",
+           },
+           "screenX": 5,
+           "screenY": 6,
+           "shiftKey": false,
+           "target": Object {
+             "@ref": "DIV",
+           },
+           "type": "mouseleave",
+           "view": Object {
+             "@ref": "Window",
+           },
+         },
+         Object {
+           "data": Object {
+             "label": "Node-1",
+           },
+           "dragging": true,
+           "id": "Node-1",
+           "measured": Object {
+             "height": 36,
+             "width": 150,
+           },
+           "position": Object {
+             "x": -2130,
+             "y": -2272,
+           },
+           "selected": true,
+           "type": "input",
+         },
+       ],
+       "name": "onNodeMouseLeave",
+     },
+     "path": Array [
+       "callbacks",
+       58,
+     ],
+     "right": undefined,
+   },
+   Object {
+     "kind": "left-only",
+     "left": Object {
+       "args": Array [
+         null,
+         Object {
+           "x": 2000,
+           "y": 2000,
+           "zoom": 1,
+         },
+       ],
+       "name": "onMoveStart",
+     },
+     "path": Array [
+       "callbacks",
+       98,
+     ],
+     "right": undefined,
+   },
+   Object {
+     "kind": "left-only",
+     "left": Object {
+       "args": Array [
+         Object {
+           "x": 2000,
+           "y": 2000,
+           "zoom": 1,
+         },
+       ],
+       "name": "onViewportChange",
+     },
+     "path": Array [
+       "callbacks",
+       99,
+     ],
+     "right": undefined,
+   },
+   Object {
+     "kind": "left-only",
+     "left": Object {
+       "args": Array [
+         null,
+         Object {
+           "x": 2000,
+           "y": 2000,
+           "zoom": 1,
+         },
+       ],
+       "name": "onMove",
+     },
+     "path": Array [
+       "callbacks",
+       100,
+     ],
+     "right": undefined,
+   },
+   Object {
+     "kind": "left-only",
+     "left": Object {
+       "args": Array [
+         Object {
+           "@class": "SyntheticBaseEvent",
+           "_reactName": "onMouseEnter",
+           "_targetInst": Object {
+             "@ref": "React fiber",
+           },
+           "altKey": false,
+           "bubbles": true,
+           "button": 0,
+           "buttons": 1,
+           "cancelable": true,
+           "clientX": 5,
+           "clientY": 5,
+           "ctrlKey": false,
+           "currentTarget": Object {
+             "@ref": "DIV",
+           },
+           "defaultPrevented": false,
+           "detail": 0,
+           "eventPhase": 3,
+           "getModifierState": Object {
+             "@ref": "function",
+           },
+           "isDefaultPrevented": Object {
+             "@ref": "function",
+           },
+           "isPropagationStopped": Object {
+             "@ref": "function",
+           },
+           "isTrusted": true,
+           "metaKey": false,
+           "movementX": 0,
+           "movementY": 0,
+           "nativeEvent": Object {
+             "@class": "MouseEvent",
+             "isTrusted": true,
+           },
+           "pageX": 5,
+           "pageY": 5,
+           "relatedTarget": Object {
+             "@ref": "DIV",
+           },
+           "screenX": 5,
+           "screenY": 5,
+           "shiftKey": false,
+           "target": Object {
+             "@ref": "DIV",
+           },
+           "type": "mouseenter",
+           "view": Object {
+             "@ref": "Window",
+           },
+         },
+         Object {
+           "data": Object {
+             "label": "Node-1",
+           },
+           "dragging": true,
+           "id": "Node-1",
+           "measured": Object {
+             "height": 36,
+             "width": 150,
+           },
+           "position": Object {
+             "x": -2069,
+             "y": -2013,
+           },
+           "selected": true,
+           "type": "input",
+         },
+       ],
+       "name": "onNodeMouseEnter",
+     },
+     "path": Array [
+       "callbacks",
+       101,
+     ],
+     "right": undefined,
+   },
+   Object {
+     "kind": "left-only",
+     "left": Object {
+       "args": Array [
+         null,
+         Object {
+           "x": 2000,
+           "y": 2000,
+           "zoom": 1,
+         },
+       ],
+       "name": "onMoveEnd",
+     },
+     "path": Array [
+       "callbacks",
+       105,
+     ],
+     "right": undefined,
+   },
+   Object {
+     "kind": "left-only",
+     "left": Object {
+       "args": Array [
+         null,
+         Object {
+           "x": 2000,
+           "y": 2000,
+           "zoom": 1,
+         },
+       ],
+       "name": "onMoveStart",
+     },
+     "path": Array [
+       "callbacks",
+       106,
+     ],
+     "right": undefined,
+   },
+   Object {
+     "kind": "left-only",
+     "left": Object {
+       "args": Array [
+         Object {
+           "x": 2000,
+           "y": 2000,
+           "zoom": 1,
+         },
+       ],
+       "name": "onViewportChange",
+     },
+     "path": Array [
+       "callbacks",
+       107,
+     ],
+     "right": undefined,
+   },
+   Object {
+     "kind": "left-only",
+     "left": Object {
+       "args": Array [
+         null,
+         Object {
+           "x": 2000,
+           "y": 2000,
+           "zoom": 1,
+         },
+       ],
+       "name": "onMove",
+     },
+     "path": Array [
+       "callbacks",
+       108,
+     ],
+     "right": undefined,
+   },
+   Object {
+     "kind": "left-only",
+     "left": Object {
+       "args": Array [
+         null,
+         Object {
+           "x": 2000,
+           "y": 2000,
+           "zoom": 1,
+         },
+       ],
+       "name": "onMoveEnd",
+     },
+     "path": Array [
+       "callbacks",
+       111,
+     ],
+     "right": undefined,
+   },
+   Object {
+     "kind": "order",
+     "left": Array [
+       "onSelectionChange#1",
+       "onNodesChange#1",
+       "onInit#1",
+       "onPaneMouseEnter#1",
+       "onNodeMouseEnter#1",
+       "onPaneMouseMove#1",
+       "onNodeMouseMove#1",
+       "onNodesChange#2",
+       "onNodeDragStart#1",
+       "onSelectionChange#2",
+       "onPaneMouseMove#2",
+       "onMoveStart#1",
+       "onViewportChange#1",
+       "onMove#1",
+       "onNodesChange#3",
+       "onNodeDrag#1",
+       "onMoveEnd#1",
+       "onMoveStart#2",
+       "onViewportChange#2",
+       "onMove#2",
+       "onNodesChange#4",
+       "onNodeDrag#2",
+       "onNodeMouseLeave#1",
+       "onMoveEnd#2",
+       "onMoveStart#3",
+       "onViewportChange#3",
+       "onMove#3",
+       "onNodesChange#5",
+       "onNodeDrag#3",
+       "onMoveEnd#3",
+       "onMoveStart#4",
+       "onViewportChange#4",
+       "onMove#4",
+       "onNodesChange#6",
+       "onNodeDrag#4",
+       "onMoveEnd#4",
+       "onMoveStart#5",
+       "onViewportChange#5",
+       "onMove#5",
+       "onNodesChange#7",
+       "onNodeDrag#5",
+       "onPaneMouseMove#3",
+       "onNodesChange#8",
+       "onNodeDrag#6",
+       "onMoveEnd#5",
+       "onMoveStart#6",
+       "onViewportChange#6",
+       "onMove#6",
+       "onNodesChange#9",
+       "onNodeDrag#7",
+       "onNodeMouseEnter#2",
+       "onMoveEnd#6",
+       "onMoveStart#7",
+       "onViewportChange#7",
+       "onMove#7",
+       "onNodesChange#10",
+       "onNodeDrag#8",
+       "onMoveEnd#7",
+       "onMoveStart#8",
+       "onViewportChange#8",
+       "onMove#8",
+       "onMoveEnd#8",
+       "onMoveStart#9",
+       "onViewportChange#9",
+       "onMove#9",
+       "onMoveEnd#9",
+       "onMoveStart#10",
+       "onViewportChange#10",
+       "onMove#10",
+       "onPaneMouseMove#4",
+       "onNodesChange#11",
+       "onNodeDrag#9",
+       "onMoveEnd#10",
+       "onMoveStart#11",
+       "onViewportChange#11",
+       "onMove#11",
+       "onMoveEnd#11",
+       "onMoveStart#12",
+       "onViewportChange#12",
+       "onMove#12",
+       "onMoveEnd#12",
+       "onMoveStart#13",
+       "onViewportChange#13",
+       "onMove#13",
+       "onMoveEnd#13",
+       "onMoveStart#14",
+       "onViewportChange#14",
+       "onMove#14",
+       "onMoveEnd#14",
+       "onMoveStart#15",
+       "onViewportChange#15",
+       "onMove#15",
+       "onMoveEnd#15",
+       "onMoveStart#16",
+       "onViewportChange#16",
+       "onMove#16",
+       "onMoveEnd#16",
+       "onPaneMouseMove#5",
+       "onNodesChange#12",
+       "onNodeDrag#10",
+       "onNodesChange#13",
+       "onNodeDragStop#1",
+     ],
+     "path": Array [
+       "callbacks",
+     ],
+     "right": Array [
+       "onSelectionChange#1",
+       "onNodesChange#1",
+       "onInit#1",
+       "onPaneMouseEnter#1",
+       "onNodeMouseEnter#1",
+       "onPaneMouseMove#1",
+       "onNodeMouseMove#1",
+       "onNodesChange#2",
+       "onNodeDragStart#1",
+       "onSelectionChange#2",
+       "onPaneMouseMove#2",
+       "onMoveStart#1",
+       "onViewportChange#1",
+       "onMove#1",
+       "onNodesChange#3",
+       "onNodeDrag#1",
+       "onMoveEnd#1",
+       "onMoveStart#2",
+       "onViewportChange#2",
+       "onMove#2",
+       "onNodesChange#4",
+       "onNodeDrag#2",
+       "onNodeMouseLeave#1",
+       "onMoveEnd#2",
+       "onMoveStart#3",
+       "onViewportChange#3",
+       "onMove#3",
+       "onNodesChange#5",
+       "onNodeDrag#3",
+       "onMoveEnd#3",
+       "onMoveStart#4",
+       "onViewportChange#4",
+       "onMove#4",
+       "onNodesChange#6",
+       "onNodeDrag#4",
+       "onMoveEnd#4",
+       "onMoveStart#5",
+       "onViewportChange#5",
+       "onMove#5",
+       "onNodesChange#7",
+       "onNodeDrag#5",
+       "onPaneMouseMove#3",
+       "onNodesChange#8",
+       "onNodeDrag#6",
+       "onMoveEnd#5",
+       "onMoveStart#6",
+       "onViewportChange#6",
+       "onMove#6",
+       "onNodesChange#9",
+       "onNodeDrag#7",
+       "onMoveEnd#6",
+       "onMoveStart#7",
+       "onViewportChange#7",
+       "onMove#7",
+       "onNodesChange#10",
+       "onNodeDrag#8",
+       "onMoveEnd#7",
+       "onMoveStart#8",
+       "onViewportChange#8",
+       "onMove#8",
+       "onMoveEnd#8",
+       "onMoveStart#9",
+       "onViewportChange#9",
+       "onMove#9",
+       "onMoveEnd#9",
+       "onPaneMouseMove#4",
+       "onNodesChange#11",
+       "onNodeDrag#9",
+       "onMoveStart#10",
+       "onViewportChange#10",
+       "onMove#10",
+       "onMoveEnd#10",
+       "onMoveStart#11",
+       "onViewportChange#11",
+       "onMove#11",
+       "onMoveEnd#11",
+       "onMoveStart#12",
+       "onViewportChange#12",
+       "onMove#12",
+       "onMoveEnd#12",
+       "onMoveStart#13",
+       "onViewportChange#13",
+       "onMove#13",
+       "onMoveEnd#13",
+       "onNodeMouseEnter#2",
+       "onPaneMouseMove#5",
+       "onNodesChange#12",
+       "onNodeDrag#10",
+       "onMoveStart#14",
+       "onViewportChange#14",
+       "onMove#14",
+       "onMoveEnd#14",
+       "onMoveStart#15",
+       "onViewportChange#15",
+       "onMove#15",
+       "onMoveEnd#15",
+       "onMoveStart#16",
+       "onViewportChange#16",
+       "onMove#16",
+       "onNodesChange#13",
+       "onNodeDragStop#1",
+       "onMoveEnd#16",
+     ],
+   },
+   Object {
+     "kind": "changed",
+     "left": 6,
+     "path": Array [
+       "callbacks",
+       50,
+       "args",
+       0,
+       "screenY",
+     ],
+     "right": 5,
+   },
+   Object {
+     "kind": "changed",
+     "left": 6,
+     "path": Array [
+       "callbacks",
+       50,
+       "args",
+       0,
+       "clientY",
+     ],
+     "right": 5,
+   },
+   Object {
+     "kind": "changed",
+     "left": 6,
+     "path": Array [
+       "callbacks",
+       50,
+       "args",
+       0,
+       "pageY",
+     ],
+     "right": 5,
+   },
+   Object {
+     "kind": "changed",
+     "left": -1780,
+     "path": Array [
+       "callbacks",
+       50,
+       "args",
+       1,
+       "position",
+       "x",
+     ],
+     "right": -2069,
+   },
+   Object {
+     "kind": "changed",
+     "left": -1932,
+     "path": Array [
+       "callbacks",
+       50,
+       "args",
+       1,
+       "position",
+       "y",
+     ],
+     "right": -2013,
+   },
+ ]
```

# Page snapshot

```yaml
- application [ref=e4]:
  - generic [ref=e6]:
    - generic:
      - generic:
        - img:
          - group "Edge from Node-1 to Node-2" [ref=e7] [cursor=pointer]
        - img:
          - group "Edge from Node-1 to Node-3" [ref=e12] [cursor=pointer]
      - generic:
        - group [active] [ref=e17]: Node-1
        - group [ref=e19]: Node-2
        - group [ref=e22]: Node-3
  - link "React Flow attribution" [ref=e26] [cursor=pointer]:
    - /url: https://reactflow.dev
    - text: React Flow
```

# Test source

```ts
  1  | // Browser-port regressions: native input/rendering and controlled app time must
  2  | // produce the complete original trace, including every callback and its order.
  3  | import { test, expect } from '@playwright/test';
  4  | import { readFileSync, existsSync } from 'node:fs';
  5  | import { routeSpace } from '../../driver/registry.mjs';
  6  | import { buildCorpus } from '../corpus/index.mjs';
  7  | import { checkSelfConsistency } from '../compare/consistency.mjs';
  8  | import { runScenario } from './scenario.mjs';
  9  | import { createPagePort } from './port.mjs';
  10 | 
  11 | const {fixtures, components} = routeSpace(process.cwd());
  12 | const corpus = buildCorpus(fixtures, components);
  13 | const rules = JSON.parse(readFileSync('parity/system/normalization.json')).rules;
  14 | const baseline = JSON.parse(readFileSync('xyflow/packages/react/package.json')).version;
  15 | const cases = [
  16 |   ['drag-node-autopan', 'onNodeDragStop'],
  17 |   ['drag-node-reports-changes', 'onNodeDragStop'],
  18 |   ['wheel-zoom-from-identity-viewport', 'onMoveEnd'],
  19 |   ['ctrl-wheel-pinches-with-panonscroll', 'onMoveEnd'],
  20 |   ['pan-after-controlled-viewport-change', 'onMoveEnd'],
  21 |   ['arrow-key-selected-node', 'onNodesChange'],
  22 | ];
  23 | 
  24 | for (const side of ['upstream', 'psflow']) {
  25 |   for (const [id, witness] of cases) {
  26 |     test(`${side} reproduces the complete ${id} trace across independent captures`, async ({page}) => {
  27 |       test.skip(!existsSync(`parity/driver/dist/${side}.js`), 'bundle not built');
  28 |       const scenario = corpus.find(s => s.id === id);
  29 |       const traces = [];
  30 |       for (const capture of [1, 2, 3]) {
  31 |         const trace = await runScenario(page, scenario, {side, capture, baseline});
  32 |         expect(trace.sections.callbacks.some(c => c.name === witness)).toBe(true);
  33 |         traces.push(trace);
  34 |       }
  35 |       for (const trace of traces.slice(1)) {
> 36 |         expect(checkSelfConsistency(traces[0], trace, {rules}).differences).toEqual([]);
     |                                                                             ^ Error: expect(received).toEqual(expected) // deep equality
  37 |       }
  38 |     });
  39 |   }
  40 | }
  41 | 
  42 | test('wheel dispatch completes its finite timeout chain before returning', async ({page}) => {
  43 |   const port = createPagePort(page);
  44 |   await port.prepareMount();
  45 |   await page.setContent(`<div style="width:500px;height:500px"></div><script>
  46 |     window.receipts = [];
  47 |     document.addEventListener('wheel', () => {
  48 |       receipts.push('wheel');
  49 |       setTimeout(() => {
  50 |         receipts.push('idle');
  51 |         setTimeout(() => receipts.push('end'), 150);
  52 |       }, 150);
  53 |     });
  54 |   </script>`);
  55 |   await port.finishMount();
  56 |   await port.wheel({x:100, y:100}, {deltaX:0, deltaY:-100});
  57 |   // No retry: returning before the chain completes is the defect.
  58 |   expect(await page.evaluate(() => window.receipts)).toEqual(['wheel', 'idle', 'end']);
  59 | });
  60 | 
```