# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: focus.spec.mjs >> psflow only auto-pans an offscreen node on keyboard focus (keyboard)
- Location: parity/system/harness/focus.spec.mjs:10:5

# Error details

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "transform: translate(-1000px, -1000px) scale(1);"
```

# Page snapshot

```yaml
- application [ref=e4]:
  - generic [ref=e6]:
    - generic:
      - generic:
        - img:
          - group "Edge from n1 to n2" [ref=e7] [cursor=pointer]
      - generic:
        - group [active] [ref=e12]: n1
        - group [ref=e15]: n2
  - generic "Control Panel" [ref=e18]:
    - button "Zoom In" [ref=e19] [cursor=pointer]:
      - img [ref=e20]
    - button "Zoom Out" [ref=e22] [cursor=pointer]:
      - img [ref=e23]
    - button "Fit View" [ref=e25] [cursor=pointer]:
      - img [ref=e26]
    - button "Toggle Interactivity" [ref=e28] [cursor=pointer]:
      - img [ref=e29]
  - img "Mini Map" [ref=e32]
  - img
  - link "React Flow attribution" [ref=e36] [cursor=pointer]:
    - /url: https://reactflow.dev
    - text: React Flow
```

# Test source

```ts
  1  | // The public node's focus behavior, with native pointer/keyboard modality.
  2  | import {test, expect} from '@playwright/test';
  3  | import {readFileSync} from 'node:fs';
  4  | import {runScenario, defineScenario} from './scenario.mjs';
  5  | import {routeOf} from '../corpus/routes.mjs';
  6  | import {createPagePort} from './port.mjs';
  7  | const baseline = JSON.parse(readFileSync('xyflow/packages/react/package.json')).version;
  8  | for (const side of ['upstream', 'psflow']) {
  9  |   for (const modality of ['pointer', 'keyboard']) {
  10 |     test(`${side} only auto-pans an offscreen node on keyboard focus (${modality})`, async ({page}) => {
  11 |       const port = createPagePort(page);
  12 |       const mount = defineScenario({
  13 |         id:'live--offscreen-focus', route:routeOf('./flow/chrome-defaults.ts'),
  14 |         async run(a) {
  15 |           await a.click('.react-flow__controls-zoomin');
  16 |           await a.call('setViewport', [{x:-1000,y:-1000,zoom:1}, {duration:0}]);
  17 |         },
  18 |       });
  19 |       await runScenario(page,mount,{side,capture:1,baseline,port});
  20 |       const viewport=page.locator('.react-flow__viewport');
  21 |       const before=await viewport.getAttribute('style');
  22 |       if (modality==='keyboard') await port.keyboard('press','Shift');
  23 |       const selector='.react-flow__node[data-id="n1"]';
  24 |       await port.focus(selector);
  25 |       expect(await page.locator(selector).evaluate(el=>el.matches(':focus-visible'))).toBe(modality==='keyboard');
  26 |       await port.tick();
  27 |       const after=await viewport.getAttribute('style');
> 28 |       if (modality==='keyboard') expect(after).not.toBe(before);
     |                                                    ^ Error: expect(received).not.toBe(expected) // Object.is equality
  29 |       else expect(after).toBe(before);
  30 |     });
  31 |   }
  32 | }
  33 | 
```