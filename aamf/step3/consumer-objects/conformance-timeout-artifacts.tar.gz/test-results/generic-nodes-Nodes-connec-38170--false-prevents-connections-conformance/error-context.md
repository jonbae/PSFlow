# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: generic-nodes.spec.ts >> Nodes >> connecting >> connectable=false prevents connections
- Location: examples/react-smoke/tests/generic-nodes.spec.ts:200:5

# Error details

```
TimeoutError: page.waitForSelector: Timeout 10000ms exceeded.
Call log:
  - waiting for locator('.react-flow') to be visible
    - locator resolved to visible <div class="react-flow" role="application" data-testid="rf__wrapper">…</div>

```

# Page snapshot

```yaml
- application [ref=e4]:
  - generic [ref=e6]:
    - generic:
      - generic:
        - img:
          - group "Edge from Node-1 to Node-2" [ref=e7] [cursor=pointer]:
            - generic [ref=e10]:
              - generic: edge
        - img:
          - group "Edge from Node-1 to Node-3" [ref=e12] [cursor=pointer]:
            - generic [ref=e15]:
              - generic: edge
      - generic:
        - group [ref=e17]: Node-1
        - group [ref=e19]: Node-2
        - group [ref=e21]: Node-3
        - group [ref=e24]: Node-4
        - group [ref=e26]
        - group [ref=e29]: notConnectable
        - group [ref=e30] [cursor=pointer]: notDraggable
        - group [ref=e33]: notSelectable
        - group [ref=e36]: notDeletable
  - link "React Flow attribution" [ref=e40] [cursor=pointer]:
    - /url: https://reactflow.dev
    - text: React Flow
```

# Test source

```ts
  1   | // Adopted from xyflow/tests/playwright/e2e/nodes.spec.ts.
  2   | // Faithful copy of upstream's framework-parameterized e2e suite; the
  3   | // ONLY changes are the two infrastructure bits that differ for PSFlow:
  4   | //   1. FRAMEWORK is hard-set to 'react' (upstream reads process.env.FRAMEWORK).
  5   | //   2. the route is loaded via the static server + hash router
  6   | //      ('/parity/driver/index.html#/tests/generic/nodes/general')
  7   | //      instead of a vite path ('/tests/generic/nodes/general').
  8   | //
  9   | // The page mounts the TSX driver with `@xyflow/react` aliased to `index.js` — so
  10  | // this spec enters through the JS surface, the door the audience comes
  11  | // through, and it mounts upstream's own `nodes/general.ts` unmodified. Run
  12  | // `npm run build:driver` after changing `src/` or re-vendoring `xyflow/`.
  13  | import { test, expect } from "@playwright/test";
  14  | 
  15  | const FRAMEWORK = "react";
  16  | const ROUTE = "/parity/driver/index.html#/tests/generic/nodes/general";
  17  | 
  18  | test.describe("Nodes", () => {
  19  |   test.beforeEach(async ({ page }) => {
  20  |     await page.goto(ROUTE);
> 21  |     await page.waitForSelector(`.${FRAMEWORK}-flow`, { timeout: 10_000 });
      |                ^ TimeoutError: page.waitForSelector: Timeout 10000ms exceeded.
  22  |   });
  23  | 
  24  |   test.describe("selection", () => {
  25  |     test("selecting a node by click", async ({ page }) => {
  26  |       const locator = page.locator(`.${FRAMEWORK}-flow__node`).first();
  27  |       await locator.click();
  28  | 
  29  |       await expect(locator).toHaveClass(/selected/);
  30  |     });
  31  | 
  32  |     test("selecting multiple nodes with shift drag", async ({ page }) => {
  33  |       let nodeSelection = page.locator(
  34  |         FRAMEWORK === "react" ? ".react-flow__nodesselection" : ".svelte-flow__selection"
  35  |       );
  36  |       let selection = page.locator(FRAMEWORK === "react" ? ".react-flow__selection" : ".svelte-flow__selection");
  37  | 
  38  |       const nodes = page.locator(`.${FRAMEWORK}-flow__node`);
  39  | 
  40  |       await expect(nodes.first()).toHaveCSS("visibility", "visible");
  41  |       await expect(nodes.nth(1)).toHaveCSS("visibility", "visible");
  42  |       await expect(nodes.nth(2)).toHaveCSS("visibility", "visible");
  43  |       const box = await nodes.first().boundingBox();
  44  | 
  45  |       await page.keyboard.down("Shift");
  46  |       await page.mouse.move(box!.x - 150, box!.y - 25);
  47  |       await page.mouse.down();
  48  |       await page.mouse.move(box!.x + 275, box!.y + 200);
  49  | 
  50  |       await expect(selection).toBeInViewport();
  51  |       await page.mouse.up();
  52  |       await page.keyboard.up("Shift");
  53  | 
  54  |       await expect(nodes.first()).toHaveClass(/selected/);
  55  |       await expect(nodes.nth(1)).toHaveClass(/selected/);
  56  |       await expect(nodes.nth(2)).toHaveClass(/selected/);
  57  | 
  58  |       await expect(nodeSelection).toBeInViewport();
  59  |     });
  60  | 
  61  |     test("selectable=false prevents selection", async ({ page }) => {
  62  |       const locator = page.locator(`.${FRAMEWORK}-flow__node`).and(page.locator('[data-id="notSelectable"]'));
  63  |       await expect(page.locator(`.${FRAMEWORK}-flow__node`).first()).toHaveCSS("visibility", "visible");
  64  |       await locator.click();
  65  | 
  66  |       await expect(locator).not.toHaveClass(/selected/);
  67  |     });
  68  |   });
  69  | 
  70  |   test.describe("dragging", () => {
  71  |     test("dragging a node", async ({ page }) => {
  72  |       const node = page.locator(`.${FRAMEWORK}-flow__node`).first();
  73  | 
  74  |       await expect(node).toHaveCSS("visibility", "visible");
  75  | 
  76  |       const transformBeforeMove = await node.evaluate((element) => {
  77  |         return element.style.transform;
  78  |       });
  79  | 
  80  |       await node.hover();
  81  |       await page.mouse.down();
  82  |       await page.mouse.move(500, 500);
  83  |       await page.mouse.up();
  84  | 
  85  |       const transformAfterMove = await node.evaluate((element) => {
  86  |         return element.style.transform;
  87  |       });
  88  | 
  89  |       expect(transformBeforeMove).not.toMatch(transformAfterMove);
  90  |     });
  91  | 
  92  |     test("draggable=false prevents dragging", async ({ page }) => {
  93  |       const node = page.locator(`.${FRAMEWORK}-flow__node`).and(page.locator('[data-id="notDraggable"]'));
  94  |       await expect(node).toHaveCSS("visibility", "visible");
  95  | 
  96  |       const transformBeforeMove = await node.evaluate((element) => {
  97  |         return element.style.transform;
  98  |       });
  99  | 
  100 |       await node.hover();
  101 |       await page.mouse.down();
  102 |       await page.mouse.move(500, 500);
  103 |       await page.mouse.up();
  104 | 
  105 |       const transformAfterMove = await node.evaluate((element) => {
  106 |         return element.style.transform;
  107 |       });
  108 | 
  109 |       expect(transformBeforeMove).toMatch(transformAfterMove);
  110 |     });
  111 | 
  112 |     test("custom drag handle works", async ({ page }) => {
  113 |       const node = page.locator(`.${FRAMEWORK}-flow__node`).and(page.locator('[data-id="drag-handle"]'));
  114 |       await expect(node).toHaveCSS("visibility", "visible");
  115 |       const dragHandle = page.locator(".custom-drag-handle");
  116 | 
  117 |       const transformBeforeMove = await node.evaluate((element) => {
  118 |         return element.style.transform;
  119 |       });
  120 | 
  121 |       const nodeBox = await node.boundingBox();
```