# Reviewed PSFlow existing-project plan

Mapping: c3f6e1349865e8289755a588a8b5f5e6a0b4f371f48d28e0b7a2a24c649c1539

Use existing Spago and npm project. No scaffold generation.

psflow-w01-viewport: Implement only W01. Retain System.Utils.General geometry. Accept six arguments in a JS call and return a JS viewport. Padding has NO default: undefined means zero; null throws upstream TypeError. Match padding parsing, malformed-value console errors and return/error behavior against the provided JS-entry regression. Runtime FFI is limited to JS property access, type tests, parseFloat and native error semantics. Keep all geometry math in PureScript. Move only this export into crossed ownership, remove exactly its two surface exceptions, and keep stage 4 and seven raw exports. Existing viewport.test.mjs is the red regression and must remain intact; do not weaken it. No other work or scaffold is authorized.
node --test parity/boundary/viewport.test.mjs passes all cases against pinned @xyflow/system
spago build succeeds; npm run parity:surface then spago test succeed
npm run parity:boundary succeeds
Only declared outputs change; core geometry, project setup, entry point, tests and comparator rules are preserved
Only viewport arity and call-convention exceptions are retired; stage 4 has seven passthrough exports
