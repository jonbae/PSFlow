# Observability Report

## Agent Invocation Timeline

_No invocations recorded._

## Parallelism Over Time

**Peak concurrent invocations:** 0

_No parallelism data._

## Cost & Token Breakdown by Agent Type

**Total tokens:** 0  
**Total cost:** $0.0000

| Agent | Invocations | Tokens | Cost (USD) |
|---|---|---|---|

## Retry Summary

_No retries recorded._

## Wave Lifecycle & Efficiency

**Execution mode:** unknown
**Phase 4 duration:** 0ms
**Completed Phase 4 tasks:** 0
**Waves planned:** 0
**Waves executed:** 0
**Wave validation runs:** 0
**Convergence iterations:** 0
**Convergence failures:** 0
**Convergence limit hits:** 0

| Signal | Value |
|---|---|
| Build command runs | 0 |
| Test command runs | 0 |
| Format command runs | 0 |
| Lint command runs | 0 |
| Command recovery attempts | 0 |
| Command infra retries | 0 |
| Recovery-loop time (ms) | 0 |
| Build/test invocations per completed task | 0.00 |
| Retry volume per completed task | 0.00 |
